import re, json, sys
srt=open(sys.argv[1],encoding='utf-8-sig').read().replace('\r\n','\n')
cues=[]
for b in srt.strip().split('\n\n'):
    L=b.strip().split('\n')
    m=re.match(r'(\S+) --> (\S+)',L[1])
    t=lambda s:int(s[:2])*3600+int(s[3:5])*60+float(s[6:].replace(',','.'))
    cues.append((t(m.group(1)),t(m.group(2)),' '.join(L[2:])))
sil=[];cur=None
for l in open(sys.argv[2]):
    k,v=l.split(': ');v=float(v)
    if k=='silence_start':cur=v
    else: sil.append((cur,v))
FIX={'বিসমিরব্বিকাল্লাজি':'বিসমি রব্বিকাল্লাজি','important':'ইম্পর্ট্যান্ট'}
corr=[]
words=[]
for i,(s,e,txt) in enumerate(cues):
    for a,b in FIX.items():
        if a in txt:
            corr.append({'cue':i+1,'time':round(s,2),'before':a,'after':b,'evidence':'user prompt spelling' if 'বিসমি' in b else 'skill 3.4: English word in Bengali script','tier':'ক'})
            txt=txt.replace(a,b)
    cues[i]=(s,e,txt)
    ws=txt.split()
    # speech segments inside cue
    segs=[(s,e)]
    for a,b in sil:
        n=[]
        for x,y in segs:
            if b<=x or a>=y: n.append((x,y))
            else:
                if a>x: n.append((x,a))
                if b<y: n.append((b,y))
        segs=n
    segs=[g for g in segs if g[1]-g[0]>0.05] or [(s,e)]
    tot=sum(y-x for x,y in segs)
    wt=[len(re.sub(r'[^\w]','',w))+1.5 for w in ws]; W=sum(wt)
    def mp(u):  # speech-time u -> absolute
        for x,y in segs:
            if u<=y-x: return x+u
            u-=y-x
        return segs[-1][1]
    acc=0
    for w,k in zip(ws,wt):
        a=mp(acc/W*tot); acc+=k; b=mp(acc/W*tot)
        # if a lands at the end of a segment, push to next start
        words.append({'w':w,'s':round(a,3),'e':round(b,3),'cue':i+1})
dur=float(sys.argv[3])
json.dump({'words':words,'cues':[{'s':s,'e':e,'t':t} for s,e,t in cues],'corrections':corr,'duration':dur},open('tools/timing.json','w'),ensure_ascii=False,indent=1)
out=[]
for i,(s,e,t) in enumerate(cues):
    f=lambda x:'%02d:%02d:%02d,%03d'%(x//3600,x%3600//60,int(x%60),round((x%1)*1000)%1000)
    out.append(f"{i+1}\n{f(s)} --> {f(e)}\n{t}\n")
open('tools/corrected.srt','w',encoding='utf-8').write('\n'.join(out))
n=len(words); span=sum(w['e']-w['s'] for w in words)
print(n,'words', round(n/(cues[-1][1]-cues[0][0])*60),'wpm, avg',round(span/n,3))
for w in words: print(w['cue'],w['s'],w['w'])
