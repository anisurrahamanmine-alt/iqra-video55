#!/usr/bin/env bash
cd out || { echo "out/ ফোল্ডার নেই — আগে npm run render চালান"; exit 1; }
echo "ব্রাউজারে খুলুন: http://localhost:8080  (Codespaces-এর PORTS ট্যাবে 8080)"
if command -v python3 >/dev/null; then python3 -m http.server 8080; else npx -y http-server -p 8080; fi
