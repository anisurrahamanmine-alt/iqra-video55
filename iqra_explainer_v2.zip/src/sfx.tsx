import React from 'react';
import {Audio, Sequence, interpolate, staticFile} from 'remotion';
import {s} from './config';
// map: file (public/sfx) -> source in user's SFX ZIP
export const SFX_MAP = {
  whoosh_a: 'swoosh.mp3', whoosh_b: 'simple whoosh.mp3', whoosh_c: 'woosh.mp3', whoosh_d: 'swoosh 2.mp3', whoosh_cine: 'whoosh cinematic.mp3',
  page_a: 'page flip.mp3', page_book: 'flipping book page.mp3', page_turn: 'page turn.mp3',
  chime_shine: 'shine.mp3', chime_twinkle: 'twinkle sparkle.mp3', chime_ding: 'ding.mp3',
  riser_reverb: 'swoosh riser reverb.mp3', riser_soft: 'riser.mp3', boom_cine: 'cinematic impact boom.mp3', thud: 'ground impact.mp3',
  marker: 'highlighter on paper.mp3', scratch: 'scratch.mp3', tap: 'soft app button tap sound.mp3',
} as const;
type Name = keyof typeof SFX_MAP;
// [sec, name, volume, maxLenSec?]
const CUES: [number, Name, number, number?][] = [
  [0.0, 'whoosh_b', 0.16], [0.85, 'marker', 0.09], [3.76, 'page_a', 0.13], [4.85, 'tap', 0.05],
  [6.62, 'tap', 0.07], [7.08, 'tap', 0.07], [7.7, 'tap', 0.07],
  [8.5, 'riser_soft', 0.12, 4.8], [13.35, 'thud', 0.11], [14.42, 'whoosh_d', 0.1],
  [15.9, 'whoosh_a', 0.12], [17.95, 'scratch', 0.06], [19.55, 'scratch', 0.06],
  [20.15, 'whoosh_c', 0.12], [20.9, 'riser_reverb', 0.13, 2.9], [23.75, 'boom_cine', 0.15], [23.77, 'chime_shine', 0.13, 3.5],
  [25.2, 'chime_ding', 0.06], [26.55, 'tap', 0.05],
  [28.45, 'whoosh_cine', 0.09, 1.6], [30.75, 'page_a', 0.09], [31.35, 'tap', 0.06], [31.85, 'page_a', 0.09], [33.2, 'tap', 0.06],
  [35.55, 'page_turn', 0.11], [37.1, 'thud', 0.07], [37.65, 'page_a', 0.09], [40.35, 'page_a', 0.09], [41.9, 'page_a', 0.09],
  [48.0, 'page_book', 0.11], [50.15, 'whoosh_b', 0.1], [51.6, 'riser_soft', 0.09, 1.9], [53.4, 'page_book', 0.09], [53.5, 'chime_shine', 0.11, 3.2],
  [56.55, 'chime_ding', 0.05], [59.2, 'chime_twinkle', 0.07],
  [60.55, 'whoosh_a', 0.11], [62.7, 'page_a', 0.09], [68.55, 'scratch', 0.06], [68.72, 'scratch', 0.05],
  [69.25, 'whoosh_cine', 0.09, 1.6], [70.4, 'riser_soft', 0.07, 2.0],
  [73.45, 'whoosh_c', 0.11], [73.6, 'page_book', 0.09], [74.25, 'marker', 0.08], [80.0, 'chime_ding', 0.05],
  [80.75, 'whoosh_d', 0.1], [83.5, 'thud', 0.13],
  [84.35, 'whoosh_a', 0.1], [85.9, 'chime_twinkle', 0.06], [89.4, 'whoosh_b', 0.07],
  [90.35, 'page_turn', 0.1], [92.2, 'riser_reverb', 0.1, 0.95], [93.1, 'boom_cine', 0.13], [93.12, 'chime_shine', 0.12, 3.0],
  [95.0, 'whoosh_cine', 0.09, 2.0], [98.45, 'tap', 0.1], [98.95, 'chime_twinkle', 0.07],
];
const LEN: Record<Name, number> = {whoosh_a: 1.08, whoosh_b: 0.57, whoosh_c: 1.15, whoosh_d: 1.05, whoosh_cine: 3.08, page_a: 0.62, page_book: 1.22, page_turn: 1.22,
  chime_shine: 5.5, chime_twinkle: 2.0, chime_ding: 2.7, riser_reverb: 6.1, riser_soft: 5.0, boom_cine: 2.08, thud: 1.44, marker: 0.55, scratch: 0.84, tap: 1.0};
export const SfxTrack: React.FC = () => (
  <>
    {CUES.map(([t, n, v, max], i) => {
      const len = s(Math.min(LEN[n], max ?? 99));
      return (
        <Sequence key={i} from={s(t)} durationInFrames={len} layout="none">
          <Audio src={staticFile(`sfx/${n}.mp3`)} volume={(f) => v * interpolate(f, [len - 10, len], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})} />
        </Sequence>
      );
    })}
  </>
);
