import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {SCENES, s, OVERLAP, DURATION} from './config';
import {useFonts} from './fonts';
import {AnimatedBg} from './components/AnimatedBg';
import {KineticCaptionBar} from './components/KineticCaptionBar';
import {SfxTrack} from './sfx';
import {Scene01} from './scenes/Scene01'; import {Scene02} from './scenes/Scene02'; import {Scene03} from './scenes/Scene03';
import {Scene04} from './scenes/Scene04'; import {Scene05} from './scenes/Scene05'; import {Scene06} from './scenes/Scene06';
import {Scene07} from './scenes/Scene07'; import {Scene08} from './scenes/Scene08'; import {Scene09} from './scenes/Scene09';
import {Scene10} from './scenes/Scene10'; import {Scene11} from './scenes/Scene11'; import {Scene12} from './scenes/Scene12';
import {Scene13} from './scenes/Scene13'; import {Scene14} from './scenes/Scene14'; import {Scene15} from './scenes/Scene15';
import {Scene16} from './scenes/Scene16'; import {Scene17} from './scenes/Scene17';
const LIST = [Scene01, Scene02, Scene03, Scene04, Scene05, Scene06, Scene07, Scene08, Scene09, Scene10, Scene11, Scene12, Scene13, Scene14, Scene15, Scene16, Scene17];
export const Main: React.FC = () => {
  useFonts();
  return (
    <AbsoluteFill style={{backgroundColor: '#F7F8F5'}}>
      <AnimatedBg />
      {LIST.map((C, i) => {
        const a = s(SCENES[i][0]), b = Math.min(s(SCENES[i][1]), DURATION);
        return <Sequence key={i} from={a} durationInFrames={Math.max(1, b - a + (i === LIST.length - 1 ? 0 : OVERLAP))} name={`Scene${i + 1}`}><C /></Sequence>;
      })}
      <KineticCaptionBar />
      <Audio src={staticFile('audio/voiceover.mp3')} volume={1} />
      <SfxTrack />
    </AbsoluteFill>
  );
};
