import React from 'react';
import {AbsoluteFill} from 'remotion';
import {useFonts} from './fonts';
import {T} from './theme';
import {Horizon, Rosette} from './components/ThemeArt';
// Static cover: the first word + short title from the voice
export const Thumbnail: React.FC = () => {
  useFonts();
  return (
    <AbsoluteFill style={{background: T.paper}}>
      <Horizon F={999} at={0} />
      <div style={{position: 'absolute', left: 0, right: 0, top: 0, height: 1300, background: 'radial-gradient(700px 900px at 50% 0%, rgba(255,244,205,0.9), transparent 70%)'}} />
      <div style={{position: 'absolute', left: 0, right: 0, top: 260, display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
        <Rosette size={160} op={0.6} />
        <div style={{fontFamily: T.fonts.sans, fontWeight: 700, fontSize: 64, color: T.ink, marginTop: 20, marginBottom: 150}}>আল্লাহর একদম প্রথম নির্দেশ</div>
        <div lang="ar" style={{fontFamily: T.fonts.arabic, fontWeight: 700, fontSize: 320, color: T.navy, direction: 'rtl', lineHeight: 1.45, textShadow: '0 0 60px rgba(241,213,138,0.7)'}}>اقْرَأْ</div>
        <div style={{fontFamily: T.fonts.display, fontWeight: 700, fontSize: 200, color: T.good, lineHeight: 1.1}}>পড়ো</div>
        <div style={{marginTop: 30, fontFamily: T.fonts.serif, fontSize: 40, color: T.navy, padding: '8px 30px', borderRadius: 999, background: T.goldSoft}}>সূরা আলাক ৯৬ : ১</div>
      </div>
    </AbsoluteFill>
  );
};
