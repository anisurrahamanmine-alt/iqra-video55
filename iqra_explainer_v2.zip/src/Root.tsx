import React from 'react';
import {Composition, Still} from 'remotion';
import {Main} from './Video';
import {Thumbnail} from './Thumbnail';
import {WIDTH, HEIGHT, FPS, DURATION, ASPECT} from './config';
export const RemotionRoot: React.FC = () => (
  <>
    <Composition id="Main" component={Main} width={WIDTH} height={HEIGHT} fps={FPS} durationInFrames={DURATION} />
    <Still id="Thumbnail" component={Thumbnail} width={ASPECT === '9:16' ? 1080 : 1280} height={ASPECT === '9:16' ? 1920 : 720} />
  </>
);
