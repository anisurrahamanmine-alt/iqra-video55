import {AUDIO_SEC} from './data/captions';
export const ASPECT: '9:16' | '16:9' = '9:16';
export const WIDTH = ASPECT === '9:16' ? 1080 : 1920;
export const HEIGHT = ASPECT === '9:16' ? 1920 : 1080;
export const FPS = 30;
export const DURATION = Math.round((AUDIO_SEC + 1) * FPS);
export const s = (sec: number) => Math.round(sec * FPS); // seconds -> frame
export const cue = (sec: number) => Math.round((sec - 0.08) * FPS); // word entrance cue
export const SAFE = {stageTop: 160, stageBottom: 1320, captionY: 1500, side: 80, center: 720};
// [start sec, end sec] per scene (from word timings)
export const SCENES: [number, number][] = [
  [0, 3.76], [3.76, 8.52], [8.52, 15.96], [15.96, 20.2], [20.2, 24.45], [24.45, 28.5],
  [28.5, 35.6], [35.6, 46.4], [46.4, 53.4], [53.4, 60.6], [60.6, 69.3], [69.3, 73.5],
  [73.5, 80.8], [80.8, 84.4], [84.4, 90.4], [90.4, 95.0], [95.0, AUDIO_SEC + 1],
];
export const OVERLAP = 12;
