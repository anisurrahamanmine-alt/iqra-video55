import React from 'react';
import {T} from '../theme';
import {lin, rnd} from '../anim';

// Arch (mihrab-like) frame — purely architectural
export const ArchFrame: React.FC<{w: number; h: number; children?: React.ReactNode; bg?: string; stroke?: string}> = ({w, h, children, bg = T.card, stroke = T.accent}) => {
  const r = w / 2;
  const d = `M0 ${h} L0 ${r} Q0 0 ${r} 0 Q${w} 0 ${w} ${r} L${w} ${h} Z`;
  return (
    <div style={{position: 'relative', width: w, height: h, filter: 'drop-shadow(0 18px 34px rgba(14,59,50,0.18))'}}>
      <svg width={w} height={h} style={{position: 'absolute', inset: 0, overflow: 'visible'}}>
        <path d={d} fill={bg} />
        <path d={d} fill="none" stroke={stroke} strokeWidth={4} opacity={0.65} transform={`translate(14 14) scale(${(w - 28) / w} ${(h - 28) / h})`} />
      </svg>
      <div style={{position: 'absolute', inset: 0, clipPath: `path('${d}')`}}>{children}</div>
    </div>
  );
};

// Mountain with a cave mouth and descending light (no human figure)
export const CaveScene: React.FC<{F: number; at: number; light: number; w?: number; h?: number}> = ({F, at, light, w = 860, h = 820}) => {
  const L = lin(F, light, light + 30);
  const sky = `linear-gradient(180deg, ${mix('#DDE7F0', '#FFF6DE', L)}, ${mix('#EEF2EC', '#FBF1D3', L)})`;
  const par = (k: number) => (F - at) * k;
  return (
    <div style={{position: 'relative', width: w, height: h, borderRadius: 36, overflow: 'hidden', background: sky, boxShadow: T.shadow, border: `2px solid rgba(201,162,39,0.3)`}}>
      {/* stars fading as light arrives */}
      <svg width={w} height={h} style={{position: 'absolute', inset: 0}}>
        {Array.from({length: 28}).map((_, i) => <circle key={i} cx={rnd(i) * w} cy={rnd(i + 40) * h * 0.45} r={1.5 + rnd(i + 2) * 2} fill={T.support} opacity={(0.35 + Math.sin((F + i * 13) / 14) * 0.2) * (1 - L * 0.8)} />)}
      </svg>
      {/* far ridge */}
      <svg width={w} height={h} style={{position: 'absolute', inset: 0, transform: `translateX(${-par(0.08)}px)`}}>
        <path d={`M-40 ${h * 0.62} L${w * 0.18} ${h * 0.48} L${w * 0.34} ${h * 0.58} L${w * 0.6} ${h * 0.44} L${w * 0.86} ${h * 0.56} L${w + 60} ${h * 0.5} L${w + 60} ${h} L-40 ${h} Z`} fill="#CFE3D9" />
      </svg>
      {/* main mountain */}
      <svg width={w} height={h} style={{position: 'absolute', inset: 0, transform: `translateX(${-par(0.15)}px) scale(${1 + (F - at) * 0.0006})`, transformOrigin: '50% 80%'}}>
        <path d={`M-60 ${h} L${w * 0.2} ${h * 0.55} L${w * 0.42} ${h * 0.3} L${w * 0.52} ${h * 0.26} L${w * 0.66} ${h * 0.42} L${w * 0.86} ${h * 0.6} L${w + 60} ${h} Z`} fill="#9FC7B5" />
        <path d={`M${w * 0.42} ${h * 0.3} L${w * 0.52} ${h * 0.26} L${w * 0.58} ${h * 0.36} L${w * 0.48} ${h * 0.4} Z`} fill="#B9D8C9" />
        {/* cave mouth */}
        <ellipse cx={w * 0.55} cy={h * 0.56} rx={52} ry={40} fill="#2F5148" />
        <ellipse cx={w * 0.55} cy={h * 0.565} rx={44} ry={32} fill={mix('#23403A', '#FFE7A6', L)} opacity={0.9} />
        <path d={`M-60 ${h} L${w * 0.12} ${h * 0.78} L${w * 0.4} ${h * 0.84} L${w * 0.7} ${h * 0.76} L${w + 60} ${h * 0.86} L${w + 60} ${h} Z`} fill="#7FB09C" />
      </svg>
      {/* descending light into cave */}
      <div style={{position: 'absolute', left: w * 0.55 - 180, top: -20, width: 360, height: h * 0.6, opacity: L * (0.85 + Math.sin(F / 8) * 0.06),
        clipPath: 'polygon(30% 0, 70% 0, 62% 100%, 38% 100%)', background: 'linear-gradient(180deg, rgba(255,246,210,0), rgba(255,240,190,0.95))'}} />
      <div style={{position: 'absolute', left: w * 0.55 - 130, top: h * 0.56 - 90, width: 260, height: 180, borderRadius: '50%', opacity: L, background: 'radial-gradient(closest-side, rgba(255,231,150,0.75), transparent)'}} />
    </div>
  );
};

// Dawn horizon (full-screen end scene)
export const Horizon: React.FC<{F: number; at: number}> = ({F, at}) => {
  const p = lin(F, at, at + 60);
  const sunY = 1380 - p * 160;
  return (
    <div style={{position: 'absolute', inset: 0}}>
      <div style={{position: 'absolute', inset: 0, background: 'linear-gradient(180deg, #F7F8F5 0%, #EAF4EE 45%, #FCEFCF 78%, #F6E2B0 100%)', opacity: p}} />
      <div style={{position: 'absolute', left: 540 - 190, top: sunY - 190, width: 380, height: 380, borderRadius: '50%', background: 'radial-gradient(closest-side, rgba(255,226,140,0.95), rgba(255,226,140,0))', opacity: p}} />
      <svg width={1080} height={1920} style={{position: 'absolute', inset: 0, opacity: p}}>
        <path d={`M-20 1500 L200 1400 L380 1460 L560 1350 L760 1450 L940 1390 L1100 1440 L1100 1920 L-20 1920 Z`} fill="#BFDCCD" transform={`translate(${-(F - at) * 0.1} 0)`} />
        <path d={`M-20 1620 L260 1540 L520 1600 L800 1530 L1100 1590 L1100 1920 L-20 1920 Z`} fill="#8DBBA6" />
        <path d={`M-20 1760 L340 1700 L700 1750 L1100 1690 L1100 1920 L-20 1920 Z`} fill="#5E9A82" />
      </svg>
    </div>
  );
};

const hex = (c: string) => [1, 3, 5].map((i) => parseInt(c.slice(i, i + 2), 16));
export const mix = (a: string, b: string, t: number) => {
  const A = hex(a), B = hex(b);
  return `rgb(${A.map((v, i) => Math.round(v + (B[i] - v) * t)).join(',')})`;
};

// rosette ornament
export const Rosette: React.FC<{size: number; rot?: number; color?: string; op?: number}> = ({size, rot = 0, color = T.accent, op = 0.5}) => (
  <svg width={size} height={size} viewBox="0 0 200 200" style={{transform: `rotate(${rot}deg)`, opacity: op}}>
    {Array.from({length: 12}).map((_, i) => <ellipse key={i} cx={100} cy={52} rx={16} ry={48} fill="none" stroke={color} strokeWidth={3} transform={`rotate(${i * 30} 100 100)`} />)}
    <circle cx={100} cy={100} r={22} fill="none" stroke={color} strokeWidth={3} />
  </svg>
);
