import React from 'react';
import {useCurrentFrame} from 'remotion';
import {CHUNKS} from '../data/captions';
import {T} from '../theme';
import {sp} from '../anim';
import {SAFE} from '../config';

export const KineticCaptionBar: React.FC = () => {
  const F = useCurrentFrame();
  let ci = -1;
  for (let i = 0; i < CHUNKS.length; i++) if (CHUNKS[i][0].s - 2 <= F) ci = i;
  if (ci < 0) return null;
  const ch = CHUNKS[ci];
  const next = CHUNKS[ci + 1];
  const end = ch[ch.length - 1].e;
  const gapOk = next ? next[0].s - end < 20 : false;
  if (!gapOk && F > end + 12) return null;
  const k = sp(F, ch[0].s - 2, 'snap');
  return (
    <div style={{position: 'absolute', left: 0, right: 0, top: SAFE.captionY - 60, display: 'flex', justifyContent: 'center'}}>
      <div style={{
        display: 'flex', gap: 14, padding: '16px 30px', borderRadius: 24, whiteSpace: 'nowrap',
        background: `linear-gradient(180deg, #17564A, ${T.navy})`, border: `2px solid rgba(241,213,138,0.45)`,
        boxShadow: '0 14px 30px rgba(14,59,50,0.28)', transform: `translateY(${(1 - k) * 18}px) scale(${0.92 + k * 0.08})`, opacity: k,
        fontFamily: T.fonts.sans, fontWeight: 800, fontSize: 56, lineHeight: 1.25,
      }}>
        {ch.map((w, i) => {
          const active = F >= w.s && (i === ch.length - 1 ? true : F < ch[i + 1].s);
          const past = F >= w.s && !active;
          return (
            <span key={i} style={{
              padding: '0 10px', borderRadius: 12,
              background: active ? T.highlight : 'transparent',
              color: active ? T.navy : past ? '#FFFFFF' : 'rgba(255,255,255,0.45)',
            }}>{w.w}</span>
          );
        })}
      </div>
    </div>
  );
};
