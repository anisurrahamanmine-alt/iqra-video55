import React from 'react';
import {T} from '../theme';
import {sp} from '../anim';
// one word that pops in at `at`
export const KWord: React.FC<{F: number; at: number; children: React.ReactNode; size?: number; role?: 'link' | 'key' | 'good' | 'bad'; style?: React.CSSProperties}> =
  ({F, at, children, size, role = 'link', style}) => {
    const p = sp(F, at, 'pop');
    const isKey = role !== 'link';
    const color = role === 'link' ? T.ink : role === 'key' ? T.navy : role === 'good' ? T.good : T.bad;
    return (
      <span style={{display: 'inline-block', opacity: Math.min(1, p * 1.5), transform: `translateY(${(1 - p) * 34}px) scale(${0.6 + 0.4 * p})`,
        fontFamily: isKey ? T.fonts.display : T.fonts.sans, fontWeight: isKey ? 700 : 600, fontSize: size ?? (isKey ? 112 : 56), color,
        textShadow: isKey ? T.textShadow : 'none', lineHeight: 1.2, ...style}}>{children}</span>
    );
  };
export const Line: React.FC<{children: React.ReactNode; gap?: number; style?: React.CSSProperties}> = ({children, gap = 18, style}) => (
  <div style={{display: 'flex', justifyContent: 'center', alignItems: 'baseline', gap, flexWrap: 'nowrap', whiteSpace: 'nowrap', ...style}}>{children}</div>
);
// Arabic phrase, words reveal in reading order (right to left)
export const Arabic: React.FC<{F: number; words: {w: string; at: number}[]; size?: number; color?: string}> = ({F, words, size = 120, color = T.navy}) => (
  <div dir="rtl" style={{display: 'flex', flexDirection: 'row', justifyContent: 'center', gap: size * 0.28, direction: 'rtl'}}>
    {words.map((x, i) => {
      const p = sp(F, x.at, 'soft');
      return <span key={i} lang="ar" style={{fontFamily: T.fonts.arabic, fontWeight: 700, fontSize: size, color, lineHeight: 1.7, opacity: p, direction: 'rtl',
        transform: `translateY(${(1 - p) * 24}px)`, filter: `blur(${(1 - p) * 6}px)`, textShadow: '0 8px 22px rgba(14,59,50,0.12)'}}>{x.w}</span>;
    })}
  </div>
);
