import React from 'react';
import {T} from '../theme';
type P = {size?: number; color?: string; fill?: string; draw?: number};
const sw = 6;
const S: React.FC<{size: number; children: React.ReactNode; vb?: string}> = ({size, children, vb = '0 0 120 120'}) => (
  <svg width={size} height={size} viewBox={vb} fill="none" strokeLinecap="round" strokeLinejoin="round" style={{overflow: 'visible'}}>{children}</svg>
);
const dash = (d?: number) => d === undefined ? {} : {pathLength: 1, strokeDasharray: 1, strokeDashoffset: 1 - d};

export const IcQuestion: React.FC<P> = ({size = 120, color = T.good, draw}) => (
  <S size={size}><path {...dash(draw)} d="M38 42 C38 20 82 18 82 42 C82 58 60 60 60 76" stroke={color} strokeWidth={12} /><circle cx={60} cy={98} r={7} fill={color} /></S>
);
export const IcPrayerMat: React.FC<P> = ({size = 120, color = T.good, fill = T.emeraldSoft}) => (
  <S size={size}><rect x={26} y={10} width={68} height={100} rx={6} fill={fill} stroke={color} strokeWidth={sw} />
    <path d="M38 50 Q38 26 60 22 Q82 26 82 50 L82 96 L38 96 Z" stroke={color} strokeWidth={4} />
    <path d="M26 104 L94 104 M30 112 L30 118 M45 112 L45 118 M60 112 L60 118 M75 112 L75 118 M90 112 L90 118" stroke={color} strokeWidth={4} /></S>
);
export const IcCrescent: React.FC<P> = ({size = 120, color = T.good, fill = T.goldSoft}) => (
  <S size={size}><path d="M74 16 A44 44 0 1 0 104 78 A36 36 0 1 1 74 16 Z" fill={fill} stroke={color} strokeWidth={sw} />
    <path d="M92 30 l3 8 8 1 -6 5 2 8 -7 -4 -7 4 2 -8 -6 -5 8 -1 z" fill={T.accent} /></S>
);
export const IcGive: React.FC<P> = ({size = 120, color = T.good, fill = T.goldSoft}) => (
  <S size={size}>
    <circle cx={60} cy={30} r={13} fill={fill} stroke={T.accent} strokeWidth={5} /><circle cx={84} cy={44} r={10} fill={fill} stroke={T.accent} strokeWidth={5} />
    <path d="M14 82 L40 70 Q50 66 60 72 L78 72 Q86 72 86 80 Q86 86 78 86 L58 86 M86 80 L104 70 Q112 68 112 76 L84 100 Q78 104 70 104 L14 104" stroke={color} strokeWidth={sw} fill="none" /></S>
);
export const IcBeads: React.FC<P> = ({size = 120, color = T.good}) => (
  <S size={size}>{Array.from({length: 14}).map((_, i) => { const a = i / 14 * Math.PI * 2; return <circle key={i} cx={60 + Math.cos(a) * 36} cy={52 + Math.sin(a) * 36} r={7} fill={T.emeraldSoft} stroke={color} strokeWidth={4} />; })}
    <path d="M60 88 L60 104 M52 112 L60 104 L68 112" stroke={color} strokeWidth={5} /></S>
);
export const IcRules: React.FC<P> = ({size = 120, color = T.good}) => (
  <S size={size}><rect x={22} y={12} width={76} height={98} rx={8} fill="#fff" stroke={color} strokeWidth={sw} />
    <path d="M38 38 H82 M38 56 H82 M38 74 H70 M38 92 H62" stroke={color} strokeWidth={5} /><rect x={44} y={4} width={32} height={16} rx={5} fill={T.emeraldSoft} stroke={color} strokeWidth={5} /></S>
);
export const IcBook: React.FC<P> = ({size = 120, color = T.good, fill = '#fff'}) => (
  <S size={size}><path d="M60 30 Q40 18 12 22 L12 96 Q40 92 60 104 Q80 92 108 96 L108 22 Q80 18 60 30 Z" fill={fill} stroke={color} strokeWidth={sw} />
    <path d="M60 30 L60 104 M24 40 Q40 38 50 44 M24 58 Q40 56 50 62 M70 44 Q80 38 96 40 M70 62 Q80 56 96 58" stroke={color} strokeWidth={4} /></S>
);
export const IcEyeClosed: React.FC<P> = ({size = 120, color = T.bad}) => (
  <S size={size}><path d="M12 56 Q60 96 108 56" stroke={color} strokeWidth={sw} /><path d="M28 72 L20 86 M48 80 L44 96 M72 80 L76 96 M92 72 L100 86" stroke={color} strokeWidth={5} /></S>
);
export const IcLamp: React.FC<P> = ({size = 120, color = T.good}) => (
  <S size={size}><path d="M60 8 L60 18 M44 18 H76 L84 36 H36 Z" stroke={color} strokeWidth={5} fill={T.emeraldSoft} />
    <path d="M40 36 Q32 70 44 96 H76 Q88 70 80 36" stroke={color} strokeWidth={sw} fill="#FFF8E1" />
    <path d="M60 52 Q50 66 60 80 Q70 66 60 52 Z" fill={T.accent} /><path d="M40 104 H80" stroke={color} strokeWidth={sw} /></S>
);
export const IcCheck: React.FC<P> = ({size = 80, color = T.good, draw}) => (
  <S size={size}><circle cx={60} cy={60} r={52} fill={T.emeraldSoft} stroke={color} strokeWidth={sw} /><path {...dash(draw)} d="M34 62 L52 80 L88 42" stroke={color} strokeWidth={11} /></S>
);
export const IcShare: React.FC<P> = ({size = 70, color = '#fff'}) => (
  <S size={size}><circle cx={88} cy={26} r={14} stroke={color} strokeWidth={sw} /><circle cx={30} cy={60} r={14} stroke={color} strokeWidth={sw} /><circle cx={88} cy={94} r={14} stroke={color} strokeWidth={sw} />
    <path d="M42 53 L76 33 M42 67 L76 87" stroke={color} strokeWidth={sw} /></S>
);
export const IcSeed: React.FC<P> = ({size = 120, color = T.good}) => (
  <S size={size}><path d="M60 110 L60 56" stroke={color} strokeWidth={sw} /><path d="M60 70 Q30 66 26 38 Q54 38 60 70 Z M60 60 Q86 52 94 24 Q66 26 60 60 Z" fill={T.emeraldSoft} stroke={color} strokeWidth={5} /></S>
);
export const IcSun: React.FC<P> = ({size = 120, color = T.accent}) => (
  <S size={size}><circle cx={60} cy={60} r={24} fill={T.goldSoft} stroke={color} strokeWidth={sw} />{Array.from({length: 8}).map((_, i) => { const a = i * Math.PI / 4; return <path key={i} d={`M${60 + Math.cos(a) * 36} ${60 + Math.sin(a) * 36} L${60 + Math.cos(a) * 50} ${60 + Math.sin(a) * 50}`} stroke={color} strokeWidth={5} />; })}</S>
);
export const IcStar: React.FC<P> = ({size = 120, color = T.support}) => (
  <S size={size}><path d="M60 12 L72 46 L108 48 L80 70 L90 106 L60 86 L30 106 L40 70 L12 48 L48 46 Z" fill="#E6EEF8" stroke={color} strokeWidth={5} /></S>
);
export const IcWave: React.FC<P> = ({size = 120, color = T.support}) => (
  <S size={size}><path d="M10 50 Q25 36 40 50 T70 50 T100 50 M10 76 Q25 62 40 76 T70 76 T100 76" stroke={color} strokeWidth={sw} /></S>
);
export const IcMountain: React.FC<P> = ({size = 120, color = T.good}) => (
  <S size={size}><path d="M8 100 L44 36 L64 66 L78 48 L112 100 Z" fill={T.emeraldSoft} stroke={color} strokeWidth={5} /></S>
);
export const IcHeartLight: React.FC<P> = ({size = 120, color = T.good}) => (
  <S size={size}><path d="M60 102 C20 74 12 50 26 34 C40 20 56 28 60 40 C64 28 80 20 94 34 C108 50 100 74 60 102 Z" fill={T.emeraldSoft} stroke={color} strokeWidth={sw} /></S>
);
