import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {T} from '../theme';
import {lin, rnd} from '../anim';
import {SCENES, s} from '../config';

// 8-point star (khatam) geometric tile
const Tile: React.FC<{id: string; size: number; color: string; op: number}> = ({id, size, color, op}) => {
  const h = size / 2, r = size * 0.36, r2 = size * 0.22;
  const sq = (rot: number) => {
    const pts = [0, 1, 2, 3].map((k) => {
      const a = (k * 90 + 45 + rot) * Math.PI / 180;
      return `${h + Math.cos(a) * r},${h + Math.sin(a) * r}`;
    });
    return pts.join(' ');
  };
  return (
    <pattern id={id} width={size} height={size} patternUnits="userSpaceOnUse">
      <g fill="none" stroke={color} strokeWidth={1.6} opacity={op}>
        <polygon points={sq(0)} /><polygon points={sq(45)} />
        <circle cx={h} cy={h} r={r2} />
        <path d={`M0 ${h} L${h - r} ${h} M${size} ${h} L${h + r} ${h} M${h} 0 L${h} ${h - r} M${h} ${size} L${h} ${h + r}`} />
      </g>
    </pattern>
  );
};

const modeAt = (F: number) => {
  const i = SCENES.findIndex(([a, b]) => F >= s(a) && F < s(b));
  const idx = i < 0 ? SCENES.length - 1 : i;
  return {idx, mode: ['geo', 'arch', 'light'][idx % 3], start: s(SCENES[idx][0])};
};

export const AnimatedBg: React.FC = () => {
  const F = useCurrentFrame();
  const {idx, start} = modeAt(F);
  const pan = F * 0.25;
  const zoom = 1.04 + Math.sin(F / 300) * 0.03;
  const cross = lin(F, start, start + 18); // crossfade between pattern variants
  const prevVariant = (idx + 2) % 3, variant = idx % 3;
  const layer = (v: number, op: number) => (
    <svg width={1080} height={1920} style={{position: 'absolute', inset: 0, opacity: op}}>
      <defs>
        <Tile id={`t${v}`} size={[180, 240, 140][v]} color={[T.good, T.accent, T.good][v]} op={[0.07, 0.08, 0.05][v]} />
      </defs>
      <g transform={`translate(${-pan % 240} ${-(pan * 0.6) % 240}) scale(${zoom})`}>
        <rect x={-300} y={-300} width={1800} height={2600} fill={`url(#t${v})`} />
      </g>
    </svg>
  );
  return (
    <AbsoluteFill style={{background: T.paper, overflow: 'hidden'}}>
      {layer(prevVariant, 1 - cross)}
      {layer(variant, cross)}
      {/* corner washes */}
      <AbsoluteFill style={{background: `radial-gradient(900px 700px at ${10 + Math.sin(F / 200) * 6}% 4%, ${T.washes[0]}, transparent 70%), radial-gradient(800px 800px at ${92 + Math.cos(F / 230) * 5}% 96%, ${T.washes[1]}, transparent 70%)`}} />
      {/* soft light from the top */}
      <AbsoluteFill style={{background: `radial-gradient(700px 900px at 50% -8%, rgba(255,250,232,${0.55 + Math.sin(F / 70) * 0.05}), transparent 70%)`}} />
      {/* floating motes */}
      <svg width={1080} height={1920} style={{position: 'absolute', inset: 0}}>
        {Array.from({length: 26}).map((_, i) => {
          const x = rnd(i) * 1080 + Math.sin((F + i * 50) / 120) * 20;
          const y = (rnd(i + 99) * 2100 - F * (0.25 + rnd(i + 7) * 0.4)) % 2100;
          const yy = y < 0 ? y + 2100 : y;
          return <circle key={i} cx={x} cy={yy - 90} r={1.5 + rnd(i + 3) * 2.5} fill={i % 3 ? T.accent : T.good} opacity={0.18 + rnd(i + 5) * 0.2} />;
        })}
      </svg>
      {/* fine noise via tiny dots */}
      <AbsoluteFill style={{backgroundImage: 'radial-gradient(rgba(14,59,50,0.035) 1px, transparent 1px)', backgroundSize: '6px 6px', mixBlendMode: 'multiply'}} />
    </AbsoluteFill>
  );
};
