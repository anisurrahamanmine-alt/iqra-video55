import React from 'react';
import {T} from '../theme';
import {lin, sp, SprName, float, easeIO} from '../anim';

export const Abs: React.FC<{x: number; y: number; w?: number; h?: number; c?: boolean; style?: React.CSSProperties; children?: React.ReactNode}> =
  ({x, y, w, h, c = true, style, children}) => (
    <div style={{position: 'absolute', left: x, top: y, width: w ?? 'max-content', height: h, transform: c ? 'translate(-50%,-50%)' : undefined, ...style}}>{children}</div>
  );

// entrance wrapper: rise + fade + scale (soft mood)
export const Enter: React.FC<{F: number; at: number; k?: SprName; dy?: number; tilt?: number; out?: number; outLen?: number; seed?: number; children?: React.ReactNode; style?: React.CSSProperties}> =
  ({F, at, k = 'soft', dy = 60, tilt = 0, out, outLen = 10, seed = 0, children, style}) => {
    const p = sp(F, at, k);
    const o = out !== undefined ? lin(F, out - outLen, out, 1, 0, easeIO) : 1;
    const fl = p > 0.98 ? float(F, seed, 4) : 0;
    return (
      <div style={{opacity: Math.min(1, p * 1.4) * o, transform: `translateY(${(1 - p) * dy + fl + (1 - o) * -30}px) scale(${0.9 + 0.1 * p}) rotate(${(1 - p) * tilt}deg)`, ...style}}>
        {children}
      </div>
    );
  };

export const Card: React.FC<{w?: number; pad?: number; r?: number; bg?: string; border?: string; style?: React.CSSProperties; children?: React.ReactNode}> =
  ({w, pad = 36, r = 34, bg = T.card, border, style, children}) => (
    <div style={{width: w, padding: pad, borderRadius: r, background: bg, boxShadow: T.shadow, border: border ?? `2px solid rgba(201,162,39,0.25)`, ...style}}>{children}</div>
  );

export const Chip: React.FC<{children?: React.ReactNode; color?: string; bg?: string; size?: number; icon?: React.ReactNode; dashed?: boolean; style?: React.CSSProperties}> =
  ({children, color = T.navy, bg = T.card, size = 42, icon, dashed, style}) => (
    <div style={{display: 'inline-flex', alignItems: 'center', gap: 16, padding: `${size * 0.32}px ${size * 0.62}px`, borderRadius: 999, background: bg,
      border: dashed ? `3px dashed ${color}66` : `2px solid ${color}33`, boxShadow: dashed ? 'none' : '0 10px 24px rgba(14,59,50,0.14)',
      fontFamily: T.fonts.sans, fontWeight: 700, fontSize: size, color, whiteSpace: 'nowrap', lineHeight: 1.2, ...style}}>
      {icon}{children}
    </div>
  );

// line drawn over something: an X cross (muted red), drawn with dashoffset
export const Cross: React.FC<{F: number; at: number; size?: number; color?: string; width?: number}> = ({F, at, size = 160, color = T.bad, width = 14}) => {
  const a = lin(F, at, at + 9), b = lin(F, at + 6, at + 15);
  const L = size * 1.42;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{overflow: 'visible'}}>
      <line x1={8} y1={8} x2={size - 8} y2={size - 8} stroke={color} strokeWidth={width} strokeLinecap="round" strokeDasharray={L} strokeDashoffset={L * (1 - a)} />
      <line x1={size - 8} y1={8} x2={8} y2={size - 8} stroke={color} strokeWidth={width} strokeLinecap="round" strokeDasharray={L} strokeDashoffset={L * (1 - b)} />
    </svg>
  );
};

// strike-through line across text
export const Strike: React.FC<{F: number; at: number; w: number; color?: string}> = ({F, at, w, color = T.bad}) => {
  const a = lin(F, at, at + 10);
  return <div style={{position: 'absolute', left: -10, top: '52%', height: 9, borderRadius: 9, background: color, width: (w + 20) * a, opacity: 0.9}} />;
};

// marker sweep behind a word
export const Marker: React.FC<{F: number; at: number; color?: string; children?: React.ReactNode; h?: string}> = ({F, at, color = T.highlight, children, h = '46%'}) => {
  const a = lin(F, at, at + 11);
  return (
    <span style={{position: 'relative', display: 'inline-block'}}>
      <span style={{position: 'absolute', left: '-4%', right: '-4%', bottom: '6%', height: h, background: color, borderRadius: 10, transform: `scaleX(${a})`, transformOrigin: 'left', opacity: 0.85}} />
      <span style={{position: 'relative'}}>{children}</span>
    </span>
  );
};

// hand-drawn underline (wave)
export const Underline: React.FC<{F: number; at: number; w: number; color?: string}> = ({F, at, w, color = T.accent}) => {
  const a = lin(F, at, at + 20);
  const d = `M4 14 Q ${w * 0.25} 2 ${w * 0.5} 12 T ${w - 4} 10`;
  return (
    <svg width={w} height={24} style={{display: 'block', margin: '0 auto'}}>
      <path d={d} fill="none" stroke={color} strokeWidth={7} strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - a} />
    </svg>
  );
};

export const Stamp: React.FC<{F: number; at: number; text: string; color?: string; rot?: number; size?: number}> = ({F, at, text, color = T.bad, rot = -8, size = 64}) => {
  const p = sp(F, at, 'slam');
  return (
    <div style={{display: 'inline-block', transform: `scale(${2 - p}) rotate(${rot}deg)`, opacity: Math.min(1, p * 2), padding: '10px 34px', border: `6px solid ${color}`, borderRadius: 18,
      color, fontFamily: T.fonts.sans, fontWeight: 800, fontSize: size, background: 'rgba(255,255,255,0.85)', whiteSpace: 'nowrap'}}>{text}</div>
  );
};

// light cone from above + pool of light below
export const LightFromAbove: React.FC<{F: number; at: number; x?: number; top?: number; h?: number; w?: number}> = ({F, at, x = 540, top = 0, h = 1100, w = 760}) => {
  const a = lin(F, at, at + 24);
  const flick = 0.92 + Math.sin(F / 9) * 0.04;
  return (
    <div style={{position: 'absolute', left: x - w / 2, top, width: w, height: h, opacity: a * flick, pointerEvents: 'none'}}>
      <div style={{position: 'absolute', inset: 0, clipPath: 'polygon(38% 0, 62% 0, 100% 100%, 0 100%)', background: 'linear-gradient(180deg, rgba(255,244,205,0.95), rgba(255,244,205,0))'}} />
      <div style={{position: 'absolute', left: '10%', right: '10%', bottom: -40, height: 140, borderRadius: '50%', background: 'radial-gradient(closest-side, rgba(241,213,138,0.55), transparent)'}} />
    </div>
  );
};

export const Pulse: React.FC<{F: number; at: number; r?: number; color?: string}> = ({F, at, r = 80, color = T.good}) => {
  if (F < at) return null;
  const t = ((F - at) % 36) / 36;
  return <div style={{position: 'absolute', left: '50%', top: '50%', width: r * 2, height: r * 2, marginLeft: -r, marginTop: -r, borderRadius: '50%', border: `4px solid ${color}`, transform: `scale(${1 + t * 1.2})`, opacity: 0.5 * (1 - t)}} />;
};

// vignette for suspense moments
export const Vignette: React.FC<{F: number; at: number; end: number; strength?: number}> = ({F, at, end, strength = 0.18}) => {
  const a = Math.min(lin(F, at, at + 15), lin(F, end - 12, end, 1, 0));
  return <div style={{position: 'absolute', inset: 0, pointerEvents: 'none', opacity: a, background: `radial-gradient(ellipse at 50% 42%, transparent 45%, rgba(14,59,50,${strength}) 100%)`}} />;
};
