import {useCurrentFrame} from 'remotion';
import {SCENES, s} from '../config';
export const useScene = (i: number) => {
  const [a, b] = SCENES[i];
  const START = s(a), END = s(b);
  return {F: useCurrentFrame() + START, START, END, len: END - START};
};
