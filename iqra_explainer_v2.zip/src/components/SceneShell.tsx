import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {lin, easeIO} from '../anim';
import {OVERLAP} from '../config';
export type Enter = 'fade' | 'pushUp' | 'zoomIn' | 'fromRight' | 'fromLeft';
export type Exit = 'fade' | 'pushUp' | 'zoomThrough' | 'toLeft' | 'scaleDown' | 'none';
// local frame 0 = scene start; len = scene length (without overlap)
export const SceneShell: React.FC<{len: number; enter?: Enter; exit?: Exit; children: React.ReactNode}> = ({len, enter = 'fade', exit = 'fade', children}) => {
  const f = useCurrentFrame();
  const i = lin(f, 0, 14, 0, 1);
  const o = exit === 'none' ? 0 : lin(f, len - 4, len + OVERLAP - 2, 0, 1, easeIO);
  let tx = 0, ty = 0, sc = 1, op = Math.min(1, i * 1.3);
  if (enter === 'pushUp') ty += (1 - i) * 120;
  if (enter === 'zoomIn') sc *= 0.9 + 0.1 * i;
  if (enter === 'fromRight') tx += (1 - i) * 200;
  if (enter === 'fromLeft') tx -= (1 - i) * 200;
  if (exit === 'pushUp') ty -= o * 140;
  if (exit === 'zoomThrough') sc *= 1 + o * 0.5;
  if (exit === 'toLeft') tx -= o * 240;
  if (exit === 'scaleDown') sc *= 1 - o * 0.12;
  op *= 1 - o;
  return <AbsoluteFill style={{opacity: op, transform: `translate(${tx}px, ${ty}px) scale(${sc})`}}>{children}</AbsoluteFill>;
};
