import {Easing, interpolate, spring} from 'remotion';
import {FPS} from './config';
export const SPR = {
  pop: {damping: 14, stiffness: 160, mass: 0.7},   // soft-theme: less overshoot
  snap: {damping: 16, stiffness: 240, mass: 0.6},
  soft: {damping: 22, stiffness: 120, mass: 0.9},
  slam: {damping: 13, stiffness: 240, mass: 0.8},
};
export type SprName = keyof typeof SPR;
export const sp = (F: number, at: number, k: SprName = 'soft') =>
  F < at ? 0 : spring({frame: F - at, fps: FPS, config: SPR[k]});
export const easeOut = Easing.bezier(0.16, 1, 0.3, 1);
export const easeIO = Easing.bezier(0.65, 0, 0.35, 1);
export const lin = (F: number, a: number, b: number, from = 0, to = 1, ease = easeOut) =>
  interpolate(F, [a, b], [from, to], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: ease});
export const fadeOut = (F: number, end: number, len = 10) => lin(F, end - len, end, 1, 0, easeIO);
export const rnd = (i: number) => { const x = Math.sin(i * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };
export const float = (F: number, seed = 0, amp = 4, per = 90) => Math.sin((F + seed * 37) / per * Math.PI * 2) * amp;
