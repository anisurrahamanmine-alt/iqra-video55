import {useEffect, useState} from 'react';
import {continueRender, delayRender, staticFile} from 'remotion';
const FACES = [
  {family: 'NotoSerifBn', file: 'NotoSerifBengali-Regular.ttf', weight: '400'},
  {family: 'NotoSerifBn', file: 'NotoSerifBengali-Bold.ttf', weight: '700'},
  {family: 'AnekBn', file: 'AnekBangla_SemiCondensed-Medium.ttf', weight: '500'},
  {family: 'AnekBn', file: 'AnekBangla_SemiCondensed-SemiBold.ttf', weight: '600'},
  {family: 'AnekBn', file: 'AnekBangla_SemiCondensed-Bold.ttf', weight: '700'},
  {family: 'AnekBn', file: 'AnekBangla_SemiCondensed-ExtraBold.ttf', weight: '800'},
  {family: 'Hind Siliguri', file: 'HindSiliguri-SemiBold.ttf', weight: '600'},
  {family: 'Hind Siliguri', file: 'HindSiliguri-Bold.ttf', weight: '700'},
  {family: 'AmiriAr', file: 'Amiri-Regular.woff2', weight: '400'},
  {family: 'AmiriAr', file: 'Amiri-Bold.woff2', weight: '700'},
];
const withTimeout = <X,>(p: Promise<X>, ms: number) =>
  Promise.race([p, new Promise<void>((r) => setTimeout(r, ms))]);
let injected = false;
const inject = () => {
  if (injected || typeof document === 'undefined') return;
  injected = true;
  const css = FACES.map((f) => `@font-face{font-family:'${f.family}';src:url('${staticFile('fonts/' + f.file)}');font-weight:${f.weight};font-display:block;}`).join('\n');
  const el = document.createElement('style');
  el.innerHTML = css;
  document.head.appendChild(el);
};
export const useFonts = () => {
  const [handle] = useState(() => delayRender('fonts', {timeoutInMilliseconds: 120000}));
  useEffect(() => {
    inject();
    Promise.all(FACES.map((f) => withTimeout(
      new FontFace(f.family, `url('${staticFile('fonts/' + f.file)}')`, {weight: f.weight})
        .load().then((l) => { (document.fonts as any).add(l); }).catch(() => {}), 25000)))
      .then(() => continueRender(handle));
  }, [handle]);
};
