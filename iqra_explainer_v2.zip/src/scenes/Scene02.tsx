import React from 'react';
import {useScene} from '../components/useScene';
import {SceneShell} from '../components/SceneShell';
import {Abs, Enter, Card, Marker} from '../components/Paper';
import {KWord, Line} from '../components/Kinetic';
import {IcPrayerMat, IcCrescent, IcGive} from '../components/Icons';
import {T} from '../theme';
import {cue} from '../config';
import {sp, float} from '../anim';
export const PILLARS = [
  {t: 'নামাজ', I: IcPrayerMat, at: 6.68},
  {t: 'রোজা', I: IcCrescent, at: 7.14},
  {t: 'যাকাত', I: IcGive, at: 7.76},
];
export const PillarCard: React.FC<{F: number; t: string; I: React.FC<{size?: number}>; i: number}> = ({F, t, I, i}) => (
  <Card w={286} pad={26} style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10, transform: `translateY(${float(F, i, 4, 100)}px)`}}>
    <I size={128} />
    <div style={{fontFamily: T.fonts.display, fontWeight: 700, fontSize: 66, color: T.navy}}>{t}</div>
  </Card>
);
const Person: React.FC<{F: number; i: number; at: number}> = ({F, i, at}) => {
  const p = sp(F, at + i * 2, 'snap');
  return (
    <svg width={64} height={96} style={{opacity: p, transform: `translateY(${(1 - p) * 20 + float(F, i, 3, 60)}px)`}}>
      <circle cx={32} cy={22} r={16} fill={i % 2 ? T.emeraldSoft : T.goldSoft} stroke={T.good} strokeWidth={4} />
      <path d="M8 92 Q8 48 32 46 Q56 48 56 92 Z" fill={i % 2 ? T.emeraldSoft : T.goldSoft} stroke={T.good} strokeWidth={4} />
    </svg>
  );
};
export const Scene02: React.FC = () => {
  const {F, len} = useScene(1);
  return (
    <SceneShell len={len} enter="pushUp" exit="fade">
      <Abs x={540} y={330}>
        <Enter F={F} at={cue(3.76)} dy={40}>
          <Card pad={34} style={{textAlign: 'center'}}>
            <Line><KWord F={F} at={cue(3.76)} size={54}>সবচেয়ে গুরুত্বপূর্ণ</KWord></Line>
            <Line><KWord F={F} at={cue(3.76)} role="key" size={104}><Marker F={F} at={cue(3.9)}>কাজ</Marker></KWord><KWord F={F} at={cue(4.12)} role="good" size={104}>কী?</KWord></Line>
          </Card>
        </Enter>
      </Abs>
      <Abs x={540} y={640}>
        <Line gap={10}>{Array.from({length: 9}).map((_, i) => <Person key={i} F={F} i={i} at={cue(4.85)} />)}</Line>
        <Line style={{marginTop: 14}}><KWord F={F} at={cue(4.85)} size={56}>বেশিরভাগ মানুষই</KWord><KWord F={F} at={cue(6.2)} size={56}>বলবে</KWord></Line>
      </Abs>
      <Abs x={540} y={1040}>
        <div style={{display: 'flex', gap: 26}}>
          {PILLARS.map((p, i) => <Enter key={i} F={F} at={cue(p.at)} k="pop" dy={80}><PillarCard F={F} t={p.t} I={p.I} i={i} /></Enter>)}
        </div>
      </Abs>
    </SceneShell>
  );
};
