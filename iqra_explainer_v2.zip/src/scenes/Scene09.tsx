import React from 'react';
import {useScene} from '../components/useScene';
import {SceneShell} from '../components/SceneShell';
import {Abs, Enter, Chip, Pulse, LightFromAbove} from '../components/Paper';
import {KWord, Line} from '../components/Kinetic';
import {IcBook} from '../components/Icons';
import {T} from '../theme';
import {cue} from '../config';
import {lin, sp, easeIO} from '../anim';
// "কিংবা অবতীর্ণ এই বাক্যগুলো যে কোরআনের অংশ — এসব কোন ধরনের পরিচয় দেওয়ারও আগে সর্বপ্রথমই তিনি বললেন, ইকরা"
const CHIPS = ['ইসলাম', 'মুসলিম', 'মনোনীত নবী', 'কোরআনের অংশ'];
export const Scene09: React.FC = () => {
  const {F, len} = useScene(8);
  const go = lin(F, cue(51.2), cue(51.2) + 18, 0, 1, easeIO); // identities slide down as "before"
  const rail = lin(F, cue(51.2), cue(52.4), 0, 1, easeIO);
  return (
    <SceneShell len={len} enter="fade" exit="fade">
      {/* the 4th identity enters; then all compress into a "later" group */}
      <Abs x={540} y={700 + go * 400}>
        <div style={{transform: `scale(${1 - go * 0.25})`, opacity: 1 - go * 0.4, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 22}}>
          <Enter F={F} at={cue(46.58)} dy={40}>
            <Line><KWord F={F} at={cue(46.58)} size={62}>অবতীর্ণ এই বাক্যগুলো যে</KWord></Line>
          </Enter>
          <Enter F={F} at={cue(48.05)} k="pop" dy={60}>
            <Chip size={92} icon={<IcBook size={104} />} color={T.navy}>কোরআনের অংশ</Chip>
          </Enter>
          <div style={{display: 'flex', gap: 16, marginTop: 20, opacity: sp(F, cue(48.83), 'soft')}}>
            {CHIPS.slice(0, 3).map((c, i) => <Chip key={i} size={46} dashed color={T.good} bg="rgba(255,255,255,0.7)">{c}</Chip>)}
          </div>
          <Line style={{marginTop: 6}}><KWord F={F} at={cue(48.83)} size={58}>এসব</KWord><KWord F={F} at={cue(50.18)} role="key" size={92}>পরিচয়</KWord><KWord F={F} at={cue(50.65)} size={58}>দেওয়ারও আগে</KWord></Line>
        </div>
      </Abs>
      {/* rail upward: first of all */}
      <div style={{position: 'absolute', left: 536, top: 1000 - rail * 520, width: 8, height: rail * 520, borderRadius: 8, background: `linear-gradient(0deg, ${T.good}22, ${T.good})`}} />
      <LightFromAbove F={F} at={cue(53.4)} top={0} h={700} w={700} />
      <Abs x={540} y={420}>
        <div style={{opacity: sp(F, cue(51.66), 'soft'), display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
          <div style={{position: 'relative', padding: '18px 44px', borderRadius: 999, background: T.good, color: '#fff', fontFamily: T.fonts.sans, fontWeight: 800, fontSize: 60, boxShadow: T.shadow,
            transform: `scale(${0.7 + 0.3 * sp(F, cue(51.66), 'pop')})`}}>সর্বপ্রথম<Pulse F={F} at={cue(52.0)} r={70} /></div>
          <div lang="ar" style={{marginTop: 10, fontFamily: T.fonts.arabic, fontWeight: 700, fontSize: 200, color: T.navy, lineHeight: 1.4, direction: 'rtl', opacity: sp(F, cue(53.53), 'soft'),
            transform: `translateY(${(1 - sp(F, cue(53.53), 'soft')) * 30}px)`, textShadow: '0 0 50px rgba(241,213,138,0.6)'}}>اقْرَأْ</div>
        </div>
      </Abs>
    </SceneShell>
  );
};
