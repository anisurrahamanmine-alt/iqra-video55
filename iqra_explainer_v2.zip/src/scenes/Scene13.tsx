import React from 'react';
import {useScene} from '../components/useScene';
import {SceneShell} from '../components/SceneShell';
import {Abs, Enter, Card, Marker, Chip} from '../components/Paper';
import {KWord, Line} from '../components/Kinetic';
import {IcBook, IcCheck} from '../components/Icons';
import {T} from '../theme';
import {cue} from '../config';
import {lin, sp, rnd, easeIO} from '../anim';
// "পড়া বা জ্ঞান অর্জন ইসলামে কতটা ইম্পর্ট্যান্ট ... প্রথম নির্দেশ থেকে সহজেই বুঝতে পারি"
export const Scene13: React.FC = () => {
  const {F, len, START} = useScene(12);
  const fill = lin(F, cue(75.69), cue(77.0), 0, 1, easeIO);
  const bp = sp(F, cue(73.6), 'soft');
  return (
    <SceneShell len={len} enter="fromRight" exit="toLeft">
      <Abs x={540} y={430}>
        <div style={{position: 'relative', width: 420, height: 340, opacity: bp, transform: `translateY(${(1 - bp) * 60}px)`}}>
          {/* rising light particles from the open book */}
          <svg width={420} height={340} style={{position: 'absolute', inset: 0, overflow: 'visible'}}>
            {Array.from({length: 18}).map((_, i) => {
              const t = ((F - START + i * 11) % 70) / 70;
              return <circle key={i} cx={210 + (rnd(i) - 0.5) * 220 + Math.sin(t * 6 + i) * 14} cy={200 - t * 220} r={3 + rnd(i + 4) * 4} fill={i % 2 ? T.accent : T.good} opacity={(1 - t) * 0.7} />;
            })}
          </svg>
          <div style={{position: 'absolute', left: 60, top: 70}}><IcBook size={300} /></div>
        </div>
      </Abs>
      <Abs x={540} y={720}>
        <Line><KWord F={F} at={cue(73.6)} size={58}>পড়া বা</KWord><KWord F={F} at={cue(74.04)} role="key" size={116}><Marker F={F} at={cue(74.3)}>জ্ঞান অর্জন</Marker></KWord></Line>
      </Abs>
      <Abs x={540} y={960}>
        <Enter F={F} at={cue(74.79)} dy={50}>
          <Card w={820} pad={34}>
            <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'baseline'}}>
              <span style={{fontFamily: T.fonts.sans, fontWeight: 600, fontSize: 48, color: T.ink}}>ইসলামে কতটা</span>
              <span style={{fontFamily: T.fonts.display, fontWeight: 700, fontSize: 64, color: T.good}}>ইম্পর্ট্যান্ট</span>
            </div>
            <div style={{marginTop: 20, height: 40, borderRadius: 20, background: T.emeraldSoft, overflow: 'hidden'}}>
              <div style={{height: '100%', width: `${fill * 100}%`, borderRadius: 20, background: `linear-gradient(90deg, ${T.good}, #10A37A)`}} />
            </div>
          </Card>
        </Enter>
      </Abs>
      <Abs x={540} y={1210}>
        <Enter F={F} at={cue(78.56)} dy={30}>
          <Chip size={50} icon={<IcCheck size={58} draw={lin(F, cue(80.03), cue(80.03) + 12)} />} color={T.good}>প্রথম নির্দেশ থেকেই বোঝা যায়</Chip>
        </Enter>
      </Abs>
    </SceneShell>
  );
};
