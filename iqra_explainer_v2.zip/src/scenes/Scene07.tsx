import React from 'react';
import {useScene} from '../components/useScene';
import {SceneShell} from '../components/SceneShell';
import {Abs, Enter, Chip} from '../components/Paper';
import {KWord, Line} from '../components/Kinetic';
import {IcPrayerMat, IcCrescent, IcGive, IcHeartLight, IcQuestion} from '../components/Icons';
import {T} from '../theme';
import {cue} from '../config';
import {float, lin} from '../anim';
// "আল্লাহ তো চাইলে প্রথমেই বলতে পারতেন যে নামাজ পড়ো, রোজা রাখো, যাকাত দাও কিংবা অমুক অমুক গুনাহ থেকে দূরে থাকো। তাই না?"
const items = [
  {t: 'নামাজ পড়ো', I: IcPrayerMat, at: 30.8},
  {t: 'রোজা রাখো', I: IcCrescent, at: 31.39},
  {t: 'যাকাত দাও', I: IcGive, at: 31.9},
  {t: 'গুনাহ থেকে দূরে থাকো', I: IcHeartLight, at: 33.24},
];
const Ghost: React.FC<{F: number; t: string; I: React.FC<{size?: number}>; i: number; wide?: boolean}> = ({F, t, I, i, wide}) => (
  <div style={{width: 860, height: 150, borderRadius: 30, border: `4px dashed ${T.good}55`, background: 'rgba(255,255,255,0.72)', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 18,
    transform: `translateY(${float(F, i, 4, 110)}px)`}}>
    <I size={96} />
    <div style={{fontFamily: T.fonts.display, fontWeight: 700, fontSize: 62, color: T.navy}}>{t}</div>
  </div>
);
export const Scene07: React.FC = () => {
  const {F, len} = useScene(6);
  const q = lin(F, cue(34.72), cue(34.72) + 10);
  return (
    <SceneShell len={len} enter="zoomIn" exit="pushUp">
      <Abs x={540} y={290}>
        <Enter F={F} at={cue(28.52)} dy={30}>
          <Line><KWord F={F} at={cue(28.52)} size={58}>আল্লাহ তো</KWord><KWord F={F} at={cue(29.1)} size={58}>চাইলে প্রথমেই</KWord></Line>
          <Line><KWord F={F} at={cue(29.9)} role="key" size={110}>বলতে পারতেন</KWord></Line>
        </Enter>
      </Abs>
      <Abs x={540} y={830} style={{opacity: 1 - q * 0.35}}>
        <div style={{display: 'flex', flexDirection: 'column', gap: 22}}>
          {items.map((x, i) => <Enter key={i} F={F} at={cue(x.at)} k="pop" dy={60} seed={i}><Ghost F={F} t={x.t} I={x.I} i={i} /></Enter>)}
        </div>
      </Abs>
      <Abs x={540} y={1250}>
        <Enter F={F} at={cue(34.72)} dy={30}><Chip size={56} icon={<IcQuestion size={58} />} color={T.good}>তাই না?</Chip></Enter>
      </Abs>
    </SceneShell>
  );
};
