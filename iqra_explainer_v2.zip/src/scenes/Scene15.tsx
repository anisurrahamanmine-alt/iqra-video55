import React from 'react';
import {useScene} from '../components/useScene';
import {SceneShell} from '../components/SceneShell';
import {Abs, Enter, Card} from '../components/Paper';
import {KWord, Line} from '../components/Kinetic';
import {T} from '../theme';
import {cue} from '../config';
import {lin, sp, easeIO} from '../anim';
// "যে ইসলাম শুরুই হয়েছে পড়ো নির্দেশ দিয়ে সেই ইসলামে অজ্ঞতার কোন জায়গা থাকতে পারে না।"
export const Scene15: React.FC = () => {
  const {F, len} = useScene(14);
  const erase = lin(F, cue(89.43), cue(89.43) + 20, 0, 1, easeIO);
  const glow = sp(F, cue(89.6), 'soft');
  return (
    <SceneShell len={len} enter="pushUp" exit="fade">
      <Abs x={540} y={430}>
        <Enter F={F} at={cue(84.48)} dy={50}>
          <Card w={820} pad={36} style={{textAlign: 'center'}} border={`3px solid ${T.good}44`}>
            <Line><KWord F={F} at={cue(84.48)} size={52}>যে ইসলাম</KWord><KWord F={F} at={cue(85.14)} role="key" size={84}>শুরুই হয়েছে</KWord></Line>
            <div style={{display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 30, marginTop: 10}}>
              <span lang="ar" style={{fontFamily: T.fonts.arabic, fontWeight: 700, fontSize: 120, color: T.navy, direction: 'rtl', opacity: sp(F, cue(85.95), 'soft')}}>اقْرَأْ</span>
              <KWord F={F} at={cue(85.95)} role="good" size={110}>পড়ো</KWord>
            </div>
            <Line><KWord F={F} at={cue(86.26)} size={52}>নির্দেশ দিয়ে</KWord></Line>
          </Card>
        </Enter>
      </Abs>
      <div style={{position: 'absolute', left: 536, top: 640, width: 8, height: lin(F, cue(87.0), cue(87.6)) * 200, background: T.good, borderRadius: 8, opacity: 0.4}} />
      <Abs x={540} y={1000}>
        <Enter F={F} at={cue(87.22)} dy={40}>
          <Line><KWord F={F} at={cue(87.22)} size={54}>সেই ইসলামে</KWord></Line>
          <div style={{position: 'relative', marginTop: 14, display: 'flex', justifyContent: 'center'}}>
            <div style={{padding: '20px 60px', borderRadius: 30, background: '#3A4442', color: '#fff', fontFamily: T.fonts.display, fontWeight: 700, fontSize: 104,
              opacity: sp(F, cue(88.03), 'soft'), WebkitMaskImage: `linear-gradient(90deg, transparent ${erase * 100}%, #000 ${erase * 100 + 8}%)`, maskImage: `linear-gradient(90deg, transparent ${erase * 100}%, #000 ${erase * 100 + 8}%)`}}>অজ্ঞতা</div>
            <div style={{position: 'absolute', inset: -30, borderRadius: 40, background: `radial-gradient(closest-side, rgba(241,213,138,${0.6 * glow * erase}), transparent)`}} />
          </div>
          <Line style={{marginTop: 18}}><KWord F={F} at={cue(88.62)} size={54}>কোন</KWord><KWord F={F} at={cue(89.08)} role="bad" size={80}>জায়গা নেই</KWord></Line>
        </Enter>
      </Abs>
    </SceneShell>
  );
};
