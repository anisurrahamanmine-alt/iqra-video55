import React from 'react';
import {useScene} from '../components/useScene';
import {SceneShell} from '../components/SceneShell';
import {Abs, Enter, Card, Chip, Strike} from '../components/Paper';
import {KWord, Line} from '../components/Kinetic';
import {IcQuestion} from '../components/Icons';
import {T} from '../theme';
import {cue} from '../config';
import {sp} from '../anim';
// "এবার আপনি জাস্ট ভাবেন — স্বয়ং আল্লাহর পক্ষ থেকে আসা এই প্রথম নির্দেশটাকে কি কোনোভাবে সাধারণ বা গুরুত্বহীন ভাবার উপায় আছে?"
const Word: React.FC<{F: number; at: number; strike: number; t: string; w: number}> = ({F, at, strike, t, w}) => (
  <Enter F={F} at={at} k="pop" dy={50}>
    <div style={{position: 'relative', padding: '18px 44px', borderRadius: 26, background: '#fff', boxShadow: T.shadow, fontFamily: T.fonts.display, fontWeight: 700, fontSize: 84, color: T.mute}}>
      <span style={{position: 'relative', display: 'inline-block'}}>{t}<Strike F={F} at={strike} w={w} /></span>
    </div>
  </Enter>
);
export const Scene11: React.FC = () => {
  const {F, len} = useScene(10);
  return (
    <SceneShell len={len} enter="pushUp" exit="zoomThrough">
      <Abs x={540} y={290}>
        <Enter F={F} at={cue(60.6)} dy={30}>
          <Line><KWord F={F} at={cue(60.6)} size={56}>এবার আপনি জাস্ট</KWord><KWord F={F} at={cue(62.15)} role="key" size={100}>ভাবেন</KWord></Line>
        </Enter>
      </Abs>
      <Abs x={540} y={640}>
        <Enter F={F} at={cue(62.76)} dy={60}>
          <Card w={820} pad={40} style={{textAlign: 'center'}} border={`3px solid ${T.good}55`}>
            <div lang="ar" style={{fontFamily: T.fonts.arabic, fontWeight: 700, fontSize: 150, color: T.navy, lineHeight: 1.35, direction: 'rtl'}}>اقْرَأْ</div>
            <Line><KWord F={F} at={cue(63.11)} size={50}>আল্লাহর পক্ষ থেকে আসা</KWord></Line>
            <Line><KWord F={F} at={cue(64.9)} role="good" size={96}>প্রথম নির্দেশ</KWord></Line>
          </Card>
        </Enter>
      </Abs>
      <Abs x={540} y={1060}>
        <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
          <Word F={F} at={cue(66.6)} strike={cue(68.6)} t="সাধারণ" w={250} />
          <KWord F={F} at={cue(67.08)} size={52}>বা</KWord>
          <Word F={F} at={cue(67.3)} strike={cue(68.75)} t="গুরুত্বহীন" w={340} />
        </div>
      </Abs>
      <Abs x={540} y={1250}>
        <div style={{opacity: sp(F, cue(68.0), 'soft')}}><Chip size={50} icon={<IcQuestion size={54} />} color={T.good}>ভাবার উপায় আছে?</Chip></div>
      </Abs>
    </SceneShell>
  );
};
