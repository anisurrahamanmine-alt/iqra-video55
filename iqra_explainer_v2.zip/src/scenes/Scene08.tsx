import React from 'react';
import {useScene} from '../components/useScene';
import {SceneShell} from '../components/SceneShell';
import {Abs, Enter} from '../components/Paper';
import {KWord, Line} from '../components/Kinetic';
import {IcBook, IcHeartLight, IcLamp} from '../components/Icons';
import {T} from '../theme';
import {cue} from '../config';
import {float, sp} from '../anim';
// "ইভেন আল্লাহ তখন এটাও বলেননি যে তোমাদের এই জীবন ব্যবস্থার নাম ইসলাম অথবা তোমরা মুসলিম। এমনকি যাকে এই কথাগুলো বলা হচ্ছে তিনি যে স্বয়ং আল্লাহর মনোনীত নবী"
export const IdCard: React.FC<{F: number; i: number; small: string; big: string; I: React.FC<{size?: number}>; tagAt: number; bigAt?: number}> = ({F, i, small, big, I, tagAt, bigAt}) => (
  <div style={{width: 880, display: 'flex', alignItems: 'center', gap: 26, background: T.card, borderRadius: 30, padding: '24px 34px', boxShadow: T.shadow, transform: `translateY(${float(F, i, 3, 120)}px)`, position: 'relative'}}>
    <div style={{width: 112, height: 112, borderRadius: 26, background: T.emeraldSoft, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0}}><I size={86} /></div>
    <div style={{flex: 1}}>
      <div style={{fontFamily: T.fonts.sans, fontWeight: 600, fontSize: 44, color: T.ink}}>{small}</div>
      <div style={{fontFamily: T.fonts.display, fontWeight: 700, fontSize: 80, color: T.navy, lineHeight: 1.2, opacity: bigAt === undefined ? 1 : sp(F, bigAt, 'soft'), minHeight: 96}}>{big}</div>
    </div>
    <div style={{position: 'absolute', right: 26, top: 22}}>
      <Enter F={F} at={tagAt} k="snap" dy={10}>
        <div style={{padding: '6px 20px', borderRadius: 999, border: `3px solid ${T.bad}`, color: T.bad, fontFamily: T.fonts.sans, fontWeight: 700, fontSize: 34, background: '#fff'}}>বলেননি</div>
      </Enter>
    </div>
  </div>
);
export const Scene08: React.FC = () => {
  const {F, len} = useScene(7);
  return (
    <SceneShell len={len} enter="pushUp" exit="scaleDown">
      <Abs x={540} y={290}>
        <Enter F={F} at={cue(35.69)} dy={30}>
          <Line><KWord F={F} at={cue(35.69)} size={56}>আল্লাহ তখন এটাও</KWord><KWord F={F} at={cue(37.1)} role="bad" size={104}>বলেননি</KWord></Line>
        </Enter>
      </Abs>
      <Abs x={540} y={560}><Enter F={F} at={cue(37.7)} dy={60}><IdCard F={F} i={0} small="জীবন ব্যবস্থার নাম" big="ইসলাম" I={IcBook} tagAt={cue(39.9)} /></Enter></Abs>
      <Abs x={540} y={820}><Enter F={F} at={cue(40.4)} dy={60}><IdCard F={F} i={1} small="তোমরা" big="মুসলিম" I={IcHeartLight} tagAt={cue(41.0)} /></Enter></Abs>
      <Abs x={540} y={1080}><Enter F={F} at={cue(41.96)} dy={60}><IdCard F={F} i={2} small="এমনকি যাকে বলা হচ্ছে, তিনি" big="মনোনীত নবী" bigAt={cue(45.29)} I={IcLamp} tagAt={cue(46.0)} /></Enter></Abs>
    </SceneShell>
  );
};
