import React from 'react';
import {AbsoluteFill} from 'remotion';
import {useScene} from '../components/useScene';
import {SceneShell} from '../components/SceneShell';
import {Abs, Enter, LightFromAbove, Marker} from '../components/Paper';
import {KWord, Line} from '../components/Kinetic';
import {IcLamp} from '../components/Icons';
import {T} from '../theme';
import {cue} from '../config';
import {lin, sp, rnd, easeIO} from '../anim';
// "একজন প্রকৃত মুসলিমের আসল মিশনই হলো সবার আগে জ্ঞান অর্জন করা।" — the big moment, alone
export const Scene16: React.FC = () => {
  const {F, len} = useScene(15);
  const big = cue(93.12);
  const clear = lin(F, big - 8, big + 4, 0, 1, easeIO);
  const bump = 1 + 0.05 * Math.sin(Math.min(1, Math.max(0, (F - big) / 10)) * Math.PI);
  return (
    <SceneShell len={len} enter="fade" exit="fade">
      <AbsoluteFill style={{background: `rgba(255,253,248,${clear * 0.7})`}} />
      <LightFromAbove F={F} at={big - 6} top={0} h={1200} w={940} />
      <Abs x={540} y={420 - clear * 60}>
        <div style={{opacity: 1 - clear * 0.4, transform: `scale(${1 - clear * 0.15})`}}>
          <Line><KWord F={F} at={cue(90.56)} size={56}>একজন প্রকৃত মুসলিমের</KWord></Line>
          <Line><KWord F={F} at={cue(91.93)} size={56}>আসল</KWord><KWord F={F} at={cue(92.29)} role="key" size={92}>মিশন</KWord></Line>
        </div>
      </Abs>
      <AbsoluteFill style={{transform: `scale(${bump})`}}>
        <Abs x={540} y={690}><div style={{opacity: sp(F, big, 'soft'), transform: `translateY(${(1 - sp(F, big, 'soft')) * 40}px)`}}><IcLamp size={170} /></div></Abs>
        <Abs x={540} y={930}>
          <Line><KWord F={F} at={big} role="key" size={120}>সবার আগে</KWord></Line>
          <Line><KWord F={F} at={cue(93.72)} role="good" size={180}><Marker F={F} at={cue(94.0)}>জ্ঞান অর্জন</Marker></KWord></Line>
        </Abs>
        <svg width={1080} height={1920} style={{position: 'absolute', inset: 0}}>
          {Array.from({length: 10}).map((_, i) => {
            const p = lin(F, cue(93.8) + i, cue(93.8) + 30 + i);
            const a = rnd(i) * Math.PI * 2;
            return <circle key={i} cx={540 + Math.cos(a) * (240 + p * 160)} cy={980 + Math.sin(a) * (120 + p * 90)} r={4} fill={T.accent} opacity={(1 - p) * 0.8 * (p > 0 ? 1 : 0)} />;
          })}
        </svg>
      </AbsoluteFill>
    </SceneShell>
  );
};
