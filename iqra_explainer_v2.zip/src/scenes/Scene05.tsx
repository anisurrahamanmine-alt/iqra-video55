import React from 'react';
import {AbsoluteFill} from 'remotion';
import {useScene} from '../components/useScene';
import {SceneShell} from '../components/SceneShell';
import {Abs, Enter, Chip, LightFromAbove} from '../components/Paper';
import {KWord, Line} from '../components/Kinetic';
import {CaveScene} from '../components/ThemeArt';
import {T} from '../theme';
import {cue, s} from '../config';
import {lin, sp, easeIO} from '../anim';
// "আল্লাহর তরফ থেকে আসা একদম প্রথম ওয়ার্ডটাই ছিল ইকরা" — cave + light, then the word alone
export const IQRA_Y = 720;
export const IqraHero: React.FC<{F: number; at: number; still?: boolean}> = ({F, at, still}) => {
  const p = still ? 1 : sp(F, at, 'slam');
  const glow = 0.5 + Math.sin(F / 20) * 0.1;
  return (
    <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', transform: `scale(${still ? 1 : 1.6 - 0.6 * p})`, opacity: Math.min(1, p * 1.6)}}>
      <div lang="ar" style={{fontFamily: T.fonts.arabic, fontWeight: 700, fontSize: 290, color: T.navy, lineHeight: 1.45, direction: 'rtl',
        textShadow: `0 0 60px rgba(241,213,138,${glow}), 0 14px 30px rgba(14,59,50,0.16)`}}>اقْرَأْ</div>
    </div>
  );
};
export const Scene05: React.FC = () => {
  const {F, len} = useScene(4);
  const reveal = cue(23.77);
  const dim = lin(F, reveal - 6, reveal + 6, 0, 1, easeIO);
  return (
    <SceneShell len={len} enter="fromRight" exit="fade">
      <AbsoluteFill style={{opacity: 1 - dim * 0.85, filter: `blur(${dim * 6}px)`, transform: `scale(${1 + lin(F, s(20.2), reveal, 0, 0.08, easeIO)})`}}>
        <Abs x={540} y={260}>
          <Enter F={F} at={cue(20.2)} dy={30}>
            <Line><KWord F={F} at={cue(20.2)} size={56}>আল্লাহর তরফ থেকে আসা</KWord></Line>
            <Line><KWord F={F} at={cue(21.77)} size={58}>একদম</KWord><KWord F={F} at={cue(22.2)} role="good" size={100}>প্রথম ওয়ার্ড</KWord></Line>
          </Enter>
        </Abs>
        <Abs x={540} y={830}>
          <Enter F={F} at={cue(20.25)} dy={70}><CaveScene F={F} at={cue(20.25)} light={cue(22.6)} w={880} h={760} /></Enter>
        </Abs>
      </AbsoluteFill>
      {/* the big moment, alone */}
      <AbsoluteFill style={{background: `rgba(255,255,255,${dim * 0.55})`}} />
      <LightFromAbove F={F} at={reveal - 4} top={0} h={1150} w={900} />
      <Abs x={540} y={IQRA_Y}><IqraHero F={F} at={reveal} /></Abs>
      <Abs x={540} y={IQRA_Y + 250}><Enter F={F} at={reveal + 6} dy={20}><Chip size={50} color={T.good} bg={T.emeraldSoft}>ইকরা</Chip></Enter></Abs>
    </SceneShell>
  );
};
