import React from 'react';
import {AbsoluteFill} from 'remotion';
import {useScene} from '../components/useScene';
import {SceneShell} from '../components/SceneShell';
import {Abs, Enter, Cross, Vignette, Pulse} from '../components/Paper';
import {KWord, Line} from '../components/Kinetic';
import {IcQuestion} from '../components/Icons';
import {PILLARS, PillarCard} from './Scene02';
import {T} from '../theme';
import {cue} from '../config';
import {lin, sp, easeIO} from '../anim';
// "কিন্তু ... একদম প্রথম নির্দেশ এর কোনটাই ছিল না। তাহলে কী ছিল সেই প্রথম"
export const Scene03: React.FC = () => {
  const {F, len, END} = useScene(2);
  const push = 1 + lin(F, cue(8.56), cue(13.3), 0, 0.06, easeIO);
  const drop = lin(F, cue(14.47), cue(14.47) + 14, 0, 1, easeIO);
  return (
    <SceneShell len={len} enter="fade" exit="fade">
      <Vignette F={F} at={cue(8.56)} end={END} />
      <AbsoluteFill style={{transform: `scale(${push})`}}>
        <Abs x={540} y={360}>
          <Enter F={F} at={cue(8.56)} dy={40} out={cue(14.47) + 6}>
            <Line><KWord F={F} at={cue(8.56)} role="key" size={92}>কিন্তু</KWord><KWord F={F} at={cue(8.93)} size={54}>জানলে অবাক হবেন</KWord></Line>
            <Line style={{marginTop: 10}}><KWord F={F} at={cue(10.05)} size={54}>আল্লাহর পক্ষ থেকে আসা</KWord></Line>
            <Line style={{marginTop: 4}}><KWord F={F} at={cue(11.55)} size={58}>একদম</KWord><KWord F={F} at={cue(12.0)} role="good" size={112}>প্রথম নির্দেশ</KWord></Line>
          </Enter>
        </Abs>
        {/* pillars carried over from scene 2 (same position) */}
        <Abs x={540} y={1040 + drop * 160} style={{opacity: 1 - drop}}>
          <div style={{display: 'flex', gap: 26}}>
            {PILLARS.map((p, i) => {
              const at = cue(13.35) + i * 5;
              const dim = lin(F, at, at + 8, 1, 0.45);
              return (
                <div key={i} style={{position: 'relative'}}>
                  <div style={{opacity: dim, filter: `saturate(${dim})`}}><PillarCard F={F} t={p.t} I={p.I} i={i} /></div>
                  <div style={{position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%,-50%)'}}><Cross F={F} at={at} size={170} /></div>
                </div>
              );
            })}
          </div>
          <Line style={{marginTop: 30}}><KWord F={F} at={cue(13.35)} size={58}>এর</KWord><KWord F={F} at={cue(13.35)} role="bad" size={96}>কোনটাই ছিল না</KWord></Line>
        </Abs>
        {/* then: what was it? */}
        <Abs x={540} y={700}>
          <div style={{opacity: sp(F, cue(14.47), 'soft'), transform: `scale(${0.7 + 0.3 * sp(F, cue(14.47), 'pop')})`, display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
            <div style={{position: 'relative', width: 260, height: 260, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
              <div style={{position: 'absolute', inset: 0, borderRadius: '50%', background: T.card, boxShadow: T.shadow}} />
              <Pulse F={F} at={cue(14.6)} r={130} color={T.accent} />
              <div style={{position: 'relative'}}><IcQuestion size={160} draw={lin(F, cue(14.47), cue(14.47) + 20)} /></div>
            </div>
            <Line style={{marginTop: 34}}><KWord F={F} at={cue(14.47)} size={60}>তাহলে কী ছিল সেই</KWord><KWord F={F} at={cue(15.58)} role="good" size={96}>প্রথম</KWord></Line>
          </div>
        </Abs>
      </AbsoluteFill>
    </SceneShell>
  );
};
