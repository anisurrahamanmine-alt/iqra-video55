import React from 'react';
import {useScene} from '../components/useScene';
import {SceneShell} from '../components/SceneShell';
import {Abs, Enter, Card, Stamp, Vignette} from '../components/Paper';
import {KWord, Line} from '../components/Kinetic';
import {IcEyeClosed} from '../components/Icons';
import {T} from '../theme';
import {cue} from '../config';
import {lin} from '../anim';
// "না বুঝে অন্ধভাবে কোন কিছু মেনে নেওয়ার নাম ধর্ম নয়।"
export const Scene14: React.FC = () => {
  const {F, len, END} = useScene(13);
  const dim = lin(F, cue(83.5), cue(83.5) + 8, 1, 0.75);
  return (
    <SceneShell len={len} enter="fromRight" exit="fade">
      <Vignette F={F} at={cue(80.9)} end={END + 8} strength={0.14} />
      <Abs x={540} y={680}>
        <Enter F={F} at={cue(80.94)} dy={60}>
          <Card w={840} pad={44} style={{textAlign: 'center', opacity: dim}}>
            <div style={{display: 'flex', justifyContent: 'center'}}><div style={{width: 200, height: 200, borderRadius: '50%', background: '#F6E7E7', display: 'flex', alignItems: 'center', justifyContent: 'center'}}><IcEyeClosed size={150} /></div></div>
            <Line style={{marginTop: 24}}><KWord F={F} at={cue(80.94)} size={56}>না বুঝে</KWord><KWord F={F} at={cue(81.4)} role="bad" size={108}>অন্ধভাবে</KWord></Line>
            <Line><KWord F={F} at={cue(81.94)} size={56}>কোন কিছু মেনে নেওয়া</KWord></Line>
          </Card>
        </Enter>
      </Abs>
      <Abs x={540} y={1110}><Stamp F={F} at={cue(83.54)} text="এর নাম ধর্ম নয়" size={70} rot={-5} /></Abs>
    </SceneShell>
  );
};
