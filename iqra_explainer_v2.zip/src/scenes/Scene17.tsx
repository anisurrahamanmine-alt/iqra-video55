import React from 'react';
import {useScene} from '../components/useScene';
import {SceneShell} from '../components/SceneShell';
import {Abs, Enter, Card} from '../components/Paper';
import {KWord, Line} from '../components/Kinetic';
import {Horizon, Rosette} from '../components/ThemeArt';
import {IcShare} from '../components/Icons';
import {T} from '../theme';
import {cue} from '../config';
import {lin, sp, float} from '../anim';
// End: dawn horizon full-screen, identity card of the topic, share CTA (no follow/subscribe button)
export const Scene17: React.FC = () => {
  const {F, len} = useScene(16);
  const sh = cue(98.5);
  const press = F < sh + 14 ? 1 : F < sh + 18 ? 0.9 : F < sh + 24 ? 1.08 : 1;
  const cur = lin(F, sh - 2, sh + 14);
  const wave = lin(F, sh + 16, sh + 40);
  return (
    <SceneShell len={len} enter="fade" exit="none">
      <Horizon F={F} at={cue(95.0)} />
      <Abs x={540} y={420}>
        <Enter F={F} at={cue(95.1)} dy={60}>
          <Card w={760} pad={34} style={{textAlign: 'center', transform: `translateY(${float(F, 1, 4, 120)}px)`}} border={`3px solid ${T.accent}55`}>
            <div style={{display: 'flex', justifyContent: 'center', marginBottom: 6}}><Rosette size={80} rot={F * 0.3} op={0.6} /></div>
            <div lang="ar" style={{fontFamily: T.fonts.arabic, fontWeight: 700, fontSize: 150, color: T.navy, direction: 'rtl', lineHeight: 1.4}}>اقْرَأْ</div>
            <div style={{fontFamily: T.fonts.display, fontWeight: 700, fontSize: 76, color: T.good}}>পড়ো</div>
            <div style={{fontFamily: T.fonts.sans, fontWeight: 600, fontSize: 40, color: T.ink, marginTop: 6}}>আল্লাহর পক্ষ থেকে প্রথম নির্দেশ</div>
            <div style={{fontFamily: T.fonts.serif, fontSize: 28, color: T.navy, marginTop: 10}}>সূরা আলাক ৯৬ : ১</div>
          </Card>
        </Enter>
      </Abs>
      <Abs x={540} y={860}>
        <Line><KWord F={F} at={cue(96.36)} size={56}>এমন আরও</KWord><KWord F={F} at={cue(97.04)} role="key" size={84}>নতুন কিছু জানতে</KWord></Line>
      </Abs>
      <Abs x={540} y={1060}>
        <div style={{position: 'relative', opacity: sp(F, cue(98.1), 'soft'), transform: `scale(${press * (0.8 + 0.2 * sp(F, cue(98.1), 'pop'))})`}}>
          <div style={{position: 'absolute', left: '50%', top: '50%', width: 360, height: 360, marginLeft: -180, marginTop: -180, borderRadius: '50%', border: `5px solid ${T.good}`, transform: `scale(${0.5 + wave * 1.4})`, opacity: (1 - wave) * (wave > 0 ? 0.6 : 0)}} />
          <div style={{display: 'flex', alignItems: 'center', gap: 22, padding: '26px 64px', borderRadius: 999, background: `linear-gradient(180deg, #10A37A, ${T.good})`,
            boxShadow: '0 10px 0 #035E44, 0 24px 40px rgba(4,120,87,0.35)', color: '#fff', fontFamily: T.fonts.sans, fontWeight: 800, fontSize: 70, position: 'relative', overflow: 'hidden'}}>
            <IcShare size={72} />শেয়ার করুন
            <div style={{position: 'absolute', top: 0, bottom: 0, width: 120, left: -160 + lin(F, cue(98.6), cue(99.4)) * 700, background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.45), transparent)', transform: 'skewX(-20deg)'}} />
          </div>
          {/* cursor */}
          <svg width={70} height={90} viewBox="0 0 70 90" style={{position: 'absolute', right: 40 - (1 - cur) * 120, top: 60 + (1 - cur) * 140, opacity: cur > 0 && F < sh + 50 ? 1 : 0}}>
            <path d="M6 4 L6 70 L22 56 L34 84 L46 78 L34 52 L56 52 Z" fill="#fff" stroke={T.navy} strokeWidth={5} strokeLinejoin="round" />
          </svg>
        </div>
      </Abs>
      <Abs x={540} y={1260}>
        <Line><KWord F={F} at={cue(100.65)} role="good" size={72}>সাথেই থাকুন</KWord></Line>
      </Abs>
    </SceneShell>
  );
};
