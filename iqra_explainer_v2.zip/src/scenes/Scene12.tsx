import React from 'react';
import {AbsoluteFill} from 'remotion';
import {useScene} from '../components/useScene';
import {SceneShell} from '../components/SceneShell';
import {Abs, Enter} from '../components/Paper';
import {KWord, Line} from '../components/Kinetic';
import {T} from '../theme';
import {cue} from '../config';
import {lin, sp, easeIO} from '../anim';
// "এর মাঝে কত গভীর তাৎপর্যই না লুকিয়ে আছে, তাই না?" — receding arches = depth
const archPath = (w: number, h: number) => `M0 ${h} L0 ${w / 2} Q0 0 ${w / 2} 0 Q${w} 0 ${w} ${w / 2} L${w} ${h} Z`;
export const Scene12: React.FC = () => {
  const {F, len} = useScene(11);
  const depth = lin(F, cue(70.48), cue(72.2), 0, 1, easeIO);
  return (
    <SceneShell len={len} enter="fade" exit="pushUp">
      <AbsoluteFill>
        <svg width={1080} height={1920} style={{position: 'absolute', inset: 0}}>
          {Array.from({length: 7}).map((_, i) => {
            const k = 1 - i * 0.13 - depth * 0.05;
            const w = 860 * k, h = 1000 * k;
            const p = sp(F, cue(69.4) + i * 4, 'soft');
            return <path key={i} d={archPath(w, h)} transform={`translate(${540 - w / 2} ${300 + (1000 - h) * 0.55})`} fill={i % 2 ? T.card : T.emeraldSoft}
              stroke={T.accent} strokeWidth={2} opacity={p * (0.95 - i * 0.05)} />;
          })}
        </svg>
        <Abs x={540} y={900}>
          <div lang="ar" style={{fontFamily: T.fonts.arabic, fontWeight: 700, fontSize: 170 - depth * 30, color: T.navy, direction: 'rtl', opacity: sp(F, cue(69.6), 'soft'),
            textShadow: `0 0 ${40 + depth * 40}px rgba(241,213,138,0.7)`}}>اقْرَأْ</div>
        </Abs>
      </AbsoluteFill>
      <Abs x={540} y={210}>
        <Enter F={F} at={cue(69.37)} dy={30}>
          <Line><KWord F={F} at={cue(69.37)} size={54}>এর মাঝে কত</KWord><KWord F={F} at={cue(70.48)} role="good" size={100}>গভীর তাৎপর্য</KWord></Line>
        </Enter>
      </Abs>
      <Abs x={540} y={1240}>
        <Enter F={F} at={cue(71.6)} dy={30}>
          <div style={{padding: '14px 40px', borderRadius: 999, background: T.card, boxShadow: T.shadow}}>
            <Line><KWord F={F} at={cue(71.64)} size={56}>লুকিয়ে আছে,</KWord><KWord F={F} at={cue(72.19)} role="key" size={70}>তাই না?</KWord></Line>
          </div>
        </Enter>
      </Abs>
    </SceneShell>
  );
};
