import React from 'react';
import {useScene} from '../components/useScene';
import {SceneShell} from '../components/SceneShell';
import {Abs, Enter, Chip, LightFromAbove, Underline} from '../components/Paper';
import {KWord, Line} from '../components/Kinetic';
import {IcLamp} from '../components/Icons';
import {IqraHero, IQRA_Y} from './Scene05';
import {T} from '../theme';
import {cue} from '../config';
import {lin, sp, easeIO, float} from '../anim';
// "অর্থাৎ পড়ো। লিটারেলি একটু ভাবতে পারছেন বিষয়টা?"
export const Scene06: React.FC = () => {
  const {F, len} = useScene(5);
  const up = lin(F, cue(25.85), cue(25.85) + 16, 0, 1, easeIO);
  return (
    <SceneShell len={len} enter="fade" exit="zoomThrough">
      <LightFromAbove F={F} at={-100} top={0} h={1150} w={900} />
      <div style={{position: 'absolute', inset: 0, background: 'rgba(255,255,255,0.55)'}} />
      <Abs x={540} y={IQRA_Y - up * 300} style={{transform: `translate(-50%,-50%) scale(${1 - up * 0.35})`}}><IqraHero F={F} at={0} still /></Abs>
      <Abs x={540} y={IQRA_Y + 250 - up * 260}>
        <Line><KWord F={F} at={cue(24.5)} size={60}>অর্থাৎ</KWord><KWord F={F} at={cue(25.24)} role="good" size={170}>পড়ো</KWord></Line>
        <Underline F={F} at={cue(25.4)} w={380} />
      </Abs>
      {/* think */}
      <Abs x={540} y={1000}>
        <div style={{position: 'relative', width: 300, height: 300, opacity: sp(F, cue(26.6), 'soft')}}>
          {[0, 1, 2].map((i) => {
            const p = sp(F, cue(26.3) + i * 5, 'snap');
            return <div key={i} style={{position: 'absolute', left: 60 + i * 50, top: 250 - i * 60, width: 20 + i * 14, height: 20 + i * 14, borderRadius: '50%', background: T.card, boxShadow: T.shadow, opacity: p}} />;
          })}
          <div style={{position: 'absolute', left: 110, top: 0, width: 190, height: 190, borderRadius: '50%', background: T.card, boxShadow: T.shadow, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `translateY(${float(F, 2, 5)}px)`}}>
            <IcLamp size={130} />
          </div>
        </div>
      </Abs>
      <Abs x={540} y={1250}>
        <Enter F={F} at={cue(25.85)} dy={40}>
          <Line><KWord F={F} at={cue(25.85)} size={54}>একটু</KWord><KWord F={F} at={cue(26.64)} role="key" size={92}>ভাবতে</KWord><KWord F={F} at={cue(26.99)} size={54}>পারছেন?</KWord></Line>
        </Enter>
      </Abs>
    </SceneShell>
  );
};
