import React from 'react';
import {useScene} from '../components/useScene';
import {SceneShell} from '../components/SceneShell';
import {Abs, Enter, Chip, Strike} from '../components/Paper';
import {KWord, Line} from '../components/Kinetic';
import {IcBeads, IcRules, IcQuestion} from '../components/Icons';
import {T} from '../theme';
import {cue} from '../config';
// "নির্দেশ? না ছিল কোন ইবাদতের কথা, না ছিল কোন কঠিন নিয়ম।"
const Row: React.FC<{F: number; at: number; strike: number; label: string; I: React.FC<{size?: number}>; w: number}> = ({F, at, strike, label, I, w}) => (
  <Enter F={F} at={at} dy={60}>
    <div style={{display: 'flex', alignItems: 'center', gap: 22, background: T.card, borderRadius: 32, padding: '26px 40px', boxShadow: T.shadow}}>
      <div style={{width: 120, height: 120, borderRadius: 28, background: T.emeraldSoft, display: 'flex', alignItems: 'center', justifyContent: 'center'}}><I size={96} /></div>
      <div>
        <div style={{fontFamily: T.fonts.sans, fontWeight: 600, fontSize: 50, color: T.ink}}>না ছিল কোন</div>
        <div style={{position: 'relative', display: 'inline-block', fontFamily: T.fonts.display, fontWeight: 700, fontSize: 96, color: T.navy, lineHeight: 1.2}}>
          {label}<Strike F={F} at={strike} w={w} />
        </div>
      </div>
    </div>
  </Enter>
);
export const Scene04: React.FC = () => {
  const {F, len} = useScene(3);
  return (
    <SceneShell len={len} enter="zoomIn" exit="toLeft">
      <Abs x={540} y={330}>
        <Enter F={F} at={cue(15.96)} dy={30}>
          <Chip size={58} icon={<IcQuestion size={62} />} color={T.good}>প্রথম নির্দেশ?</Chip>
        </Enter>
      </Abs>
      <Abs x={540} y={680}><Row F={F} at={cue(16.7)} strike={cue(17.99)} label="ইবাদতের কথা" I={IcBeads} w={520} /></Abs>
      <Abs x={540} y={1010}><Row F={F} at={cue(18.28)} strike={cue(19.6)} label="কঠিন নিয়ম" I={IcRules} w={440} /></Abs>
    </SceneShell>
  );
};
