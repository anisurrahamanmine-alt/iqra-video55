import React from 'react';
import {useScene} from '../components/useScene';
import {SceneShell} from '../components/SceneShell';
import {Abs, Enter, Marker} from '../components/Paper';
import {KWord, Line, Arabic} from '../components/Kinetic';
import {ArchFrame, Rosette} from '../components/ThemeArt';
import {IcSun, IcStar, IcMountain, IcWave, IcSeed} from '../components/Icons';
import {T} from '../theme';
import {cue} from '../config';
import {sp, float} from '../anim';
// Verse 96:1 — exact Arabic from the user's prompt; Bengali meaning from the voice
export const Scene10: React.FC = () => {
  const {F, len} = useScene(9);
  const icons = [IcSun, IcStar, IcMountain, IcWave, IcSeed];
  return (
    <SceneShell len={len} enter="zoomIn" exit="fade">
      <Abs x={540} y={760}>
        <Enter F={F} at={cue(53.45)} dy={70}>
          <ArchFrame w={940} h={1110}>
            <div style={{position: 'absolute', left: 0, right: 0, top: 70, display: 'flex', justifyContent: 'center'}}><Rosette size={150} rot={F * 0.2} op={0.55} /></div>
            <div style={{position: 'absolute', left: 0, right: 0, top: 230}}>
              <Arabic F={F} size={96} words={[{w: 'اقْرَأْ', at: cue(53.53)}, {w: 'بِاسْمِ', at: cue(53.92)}, {w: 'رَبِّكَ', at: cue(54.35)}]} />
              <div style={{marginTop: -20}}><Arabic F={F} size={96} words={[{w: 'الَّذِي', at: cue(54.75)}, {w: 'خَلَقَ', at: cue(55.17)}]} /></div>
            </div>
            <div style={{position: 'absolute', left: 120, right: 120, top: 640, height: 3, background: `linear-gradient(90deg, transparent, ${T.accent}, transparent)`, opacity: sp(F, cue(55.6), 'soft')}} />
            <div style={{position: 'absolute', left: 0, right: 0, top: 670}}>
              <Line><KWord F={F} at={cue(56.6)} role="good" size={92}>পড়ো</KWord></Line>
              <Line><KWord F={F} at={cue(57.17)} size={52}>তোমার</KWord><KWord F={F} at={cue(57.6)} role="key" size={64}><Marker F={F} at={cue(57.8)}>প্রতিপালকের</Marker></KWord><KWord F={F} at={cue(58.42)} size={52}>নামে,</KWord></Line>
              <Line style={{marginTop: 4}}><KWord F={F} at={cue(58.71)} size={52}>যিনি</KWord><KWord F={F} at={cue(59.23)} role="key" size={64}>সবকিছু সৃষ্টি</KWord><KWord F={F} at={cue(60.05)} size={52}>করেছেন</KWord></Line>
            </div>
            <div style={{position: 'absolute', left: 0, right: 0, top: 960, display: 'flex', justifyContent: 'center', gap: 26}}>
              {icons.map((I, i) => {
                const p = sp(F, cue(59.23) + i * 3, 'pop');
                return <div key={i} style={{opacity: p, transform: `translateY(${(1 - p) * 30 + float(F, i, 4, 70)}px) scale(${0.6 + 0.4 * p})`}}><I size={70} /></div>;
              })}
            </div>
          </ArchFrame>
        </Enter>
      </Abs>
      <Abs x={540} y={1290}>
        <Enter F={F} at={cue(56.0)} k="snap" dy={20}>
          <div style={{fontFamily: T.fonts.serif, fontWeight: 400, fontSize: 30, color: T.navy, padding: '6px 22px', borderRadius: 999, background: T.goldSoft, border: `2px solid ${T.accent}66`}}>সূরা আলাক ৯৬ : ১</div>
        </Enter>
      </Abs>
    </SceneShell>
  );
};
