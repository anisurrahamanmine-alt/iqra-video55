import React from 'react';
import {AbsoluteFill} from 'remotion';
import {useScene} from '../components/useScene';
import {SceneShell} from '../components/SceneShell';
import {Abs, Enter, Marker, Pulse} from '../components/Paper';
import {KWord, Line} from '../components/Kinetic';
import {IcQuestion} from '../components/Icons';
import {T} from '../theme';
import {cue} from '../config';
import {lin, sp, easeIO} from '../anim';
// Hook: "যদি কাউকে প্রশ্ন করা হয় / ইসলামের সবচেয়ে গুরুত্বপূর্ণ"
export const Scene01: React.FC = () => {
  const {F, len} = useScene(0);
  const cam = 1.22 - 0.22 * sp(F, 0, 'soft');
  const up = lin(F, cue(2.0), cue(2.0) + 12, 0, 1, easeIO); // first block moves up
  const q = lin(F, 2, 26);
  return (
    <SceneShell len={len} enter="fade" exit="pushUp">
      <AbsoluteFill style={{transform: `scale(${cam})`}}>
        {/* ghost foreshadow of the first word */}
        <Abs x={540} y={760}><div lang="ar" style={{fontFamily: T.fonts.arabic, fontSize: 520, color: T.good, opacity: 0.06 * q, fontWeight: 700, transform: `translateY(${-F * 0.3}px)`}}>اقْرَأْ</div></Abs>
        <Abs x={540} y={380 - up * 40}>
          <div style={{position: 'relative', width: 240, height: 240, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${0.6 + 0.4 * sp(F, 0, 'pop')})`}}>
            <div style={{position: 'absolute', inset: 0, borderRadius: '50%', background: T.card, boxShadow: T.shadow, border: `3px solid ${T.highlight}`}} />
            <Pulse F={F} at={10} r={120} />
            <div style={{position: 'relative'}}><IcQuestion size={150} draw={lin(F, 0, 20)} /></div>
          </div>
        </Abs>
        <Abs x={540} y={740 - up * 60} style={{opacity: 1 - up * 0.45, transform: `translate(-50%,-50%) scale(${1 - up * 0.15})`}}>
          <Line><KWord F={F} at={cue(0.24)} size={64}>যদি</KWord><KWord F={F} at={cue(0.505)} size={64}>কাউকে</KWord></Line>
          <Line style={{marginTop: 6}}><KWord F={F} at={cue(0.847)} role="key" size={118}><Marker F={F} at={cue(1.0)}>প্রশ্ন</Marker></KWord><KWord F={F} at={cue(1.264)} size={64}>করা হয়</KWord></Line>
        </Abs>
        <Abs x={540} y={1070}>
          <Enter F={F} at={cue(2.05)} dy={50}>
            <Line><KWord F={F} at={cue(2.05)} size={64}>ইসলামের</KWord><KWord F={F} at={cue(2.55)} size={64}>সবচেয়ে</KWord></Line>
            <Line style={{marginTop: 4}}><KWord F={F} at={cue(3.11)} role="good" size={136}>গুরুত্বপূর্ণ</KWord></Line>
          </Enter>
        </Abs>
      </AbsoluteFill>
    </SceneShell>
  );
};
