// Theme 6 (religious, calm) — user colour choice: "সাদা কাগজ ও এমারেল্ড"
export const THEME = {
  id: 'religious-calm', era: '7th-century-revelation',
  paper: '#F7F8F5', card: '#FFFFFF', ink: '#1F2937', navy: '#0E3B32',
  highlight: '#F1D58A', good: '#047857', bad: '#9B2C2C', accent: '#C9A227', support: '#1D4E89',
  emeraldSoft: '#D9EFE6', goldSoft: '#FBF1D3', mute: '#5B6B66',
  washes: ['rgba(4,120,87,0.13)', 'rgba(201,162,39,0.14)'],
  bgModes: ['geo', 'arch', 'light'] as const,
  texture: 'fine_noise', photo: {sepia: 0, saturate: 1, frame: 'clean'},
  art: 'geometric', transitions: ['fade', 'zoomThrough', 'pushUp'],
  sfxFlavour: ['whoosh', 'page', 'chime', 'riser'], music: 'none', mood: 'soft',
  fonts: {
    display: "'NotoSerifBn', 'Hind Siliguri', 'Noto Sans Bengali', serif",
    sans: "'AnekBn', 'Hind Siliguri', 'Noto Sans Bengali', sans-serif",
    serif: "'NotoSerifBn', 'Hind Siliguri', serif",
    arabic: "'AmiriAr', 'Noto Naskh Arabic', serif",
  },
  shadow: '0 18px 40px rgba(14,59,50,0.18)',
  textShadow: '0 3px 0 rgba(14,59,50,0.08), 0 10px 24px rgba(14,59,50,0.10)',
};
export const T = THEME;
