# CREDITS
- ভয়েসওভার, SRT: ব্যবহারকারী
- SFX (public/sfx/*): ব্যবহারকারীর Sound_Effects_SFX.zip থেকে; মূল নাম src/sfx.tsx-এর SFX_MAP-এ
- বাংলা ফন্ট: ব্যবহারকারীর Fonts.zip (Noto Serif Bengali, Anek Bangla, Hind Siliguri)
- Amiri (public/fonts/Amiri-*.woff2): npm @fontsource/amiri 5.3.0 থেকে নামানো — SIL Open Font License 1.1 (public/fonts/Amiri-OFL.txt); আয়াতের আরবি লেখার জন্য
- কোডে সংশ্লেষিত অ্যাসেট: নেই। মিউজিক: নেই।
