# মোবাইল থেকে রেন্ডার (GitHub Codespaces)
1. GitHub-এ নতুন রিপো বানান → Code → Codespaces → Create codespace (২ বা ৪-কোর)।
2. ZIP আপলোড করুন (Explorer-এ ড্র্যাগ বা Upload), তারপর COMMANDS.txt-এর কমান্ডগুলো চালান।
3. রেন্ডার শেষে out/video.mp4 ডান-ক্লিক → Download; না হলে `npm run download`, তারপর PORTS ট্যাবে 8080 খুলুন।
রেন্ডার-সময় আন্দাজ: ২-কোরে ~১০–১৫ মিনিট, ৪-কোরে ~৬–৮ মিনিট।
বিকল্প: Actions ট্যাব → render → Run workflow → শেষে Artifacts থেকে ভিডিও নামান।
