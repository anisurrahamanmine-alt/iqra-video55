#!/usr/bin/env bash
set -e
npm install
bash setup-linux.sh
npx remotion render Main out/video.mp4 --concurrency=100% --timeout=120000
npx remotion still Thumbnail out/thumbnail.png
